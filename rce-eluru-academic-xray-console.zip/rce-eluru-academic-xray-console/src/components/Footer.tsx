import React from 'react';

export const Footer: React.FC = () => (
  <footer className="w-full py-3 px-4 border-t border-slate-900 bg-[#070b14] text-center text-xs text-slate-400 flex items-center justify-center gap-2">
    <span className="font-mono">135 parts · 327 real tools · one map</span>
    <span>·</span>
    <strong className="text-amber-300">Developed by Maneesha L.L.S.</strong>
    <span>·</span>
    <span>Ramachandra College of Engineering (Autonomous), Eluru (NAAC A+ &amp; NBA)</span>
  </footer>
);
