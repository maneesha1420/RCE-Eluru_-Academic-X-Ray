import React from 'react';
import { Point2D, buildXRayBezierPath } from '../utils/geometry';

interface RayProps {
  id: string;
  source: Point2D;
  target: Point2D;
  highlighted?: boolean;
}

export const Ray: React.FC<RayProps> = ({ id, source, target, highlighted = false }) => {
  const d = buildXRayBezierPath(source, target, 0.4);
  return (
    <g>
      <path d={d} fill="none" stroke={highlighted ? '#F5B700' : '#1E3F78'} strokeWidth={highlighted ? 5 : 2.5} strokeOpacity={0.4} />
      <path id={id} d={d} fill="none" stroke={highlighted ? '#FFCC33' : '#38BDF8'} strokeWidth={highlighted ? 2.2 : 1.4} strokeDasharray="6 5" />
    </g>
  );
};
