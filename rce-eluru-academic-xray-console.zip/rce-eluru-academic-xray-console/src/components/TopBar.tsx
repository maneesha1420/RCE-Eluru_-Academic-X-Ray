import React from 'react';
import { Zap, Map as MapIcon, Star } from 'lucide-react';

export interface TopBarProps {
  partsCount: number;
  xrayOn: boolean;
  onToggleXray: () => void;
  onOpenWholeMap: () => void;
  onOpenCredits: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  partsCount,
  xrayOn,
  onToggleXray,
  onOpenWholeMap,
  onOpenCredits,
}) => {
  return (
    <header className="w-full h-16 px-6 flex items-center justify-between border-b border-slate-800/80 bg-[#070b14]/90 backdrop-blur-md">
      <div className="flex items-center gap-2.5">
        <span className="text-lg font-extrabold text-white">RCE</span>
        <span className="text-lg font-extrabold text-sky-400">Xray</span>
        <span className="ml-2 text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-amber-500/15 text-amber-300 border border-amber-400/30">
          Eluru • NAAC A+
        </span>
      </div>
      <div className="flex items-center gap-3">
        <span className="font-mono text-xs text-slate-300">{partsCount}/135</span>
        <button type="button" onClick={onToggleXray} className="px-3.5 py-1.5 rounded-full border border-slate-700 text-xs font-semibold flex items-center gap-2">
          <Zap className="w-3.5 h-3.5 text-amber-400" />
          <span>X-ray</span>
        </button>
        <button type="button" onClick={onOpenWholeMap} className="px-3.5 py-1.5 rounded-full border border-slate-700 text-xs font-semibold flex items-center gap-1.5">
          <MapIcon className="w-3.5 h-3.5 text-sky-400" />
          <span>Whole map</span>
        </button>
        <button type="button" onClick={onOpenCredits} className="px-3.5 py-1.5 rounded-full border border-amber-400/50 text-xs font-semibold flex items-center gap-1.5">
          <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
          <span>Developed by Maneesha L.L.S.</span>
        </button>
      </div>
    </header>
  );
};
