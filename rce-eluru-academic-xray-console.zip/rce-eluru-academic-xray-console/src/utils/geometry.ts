export interface Point2D {
  x: number;
  y: number;
}

export function polarToCartesian(
  centerX: number,
  centerY: number,
  radius: number,
  angleInDegrees: number
): Point2D {
  const angleInRadians = ((angleInDegrees - 90) * Math.PI) / 180.0;
  return {
    x: Number((centerX + radius * Math.cos(angleInRadians)).toFixed(2)),
    y: Number((centerY + radius * Math.sin(angleInRadians)).toFixed(2)),
  };
}

export function buildXRayBezierPath(
  source: Point2D,
  target: Point2D,
  curvature = 0.35
): string {
  const dx = target.x - source.x;
  const dy = target.y - source.y;
  const cx1 = source.x + dx * curvature;
  const cy1 = source.y + dy * 0.1;
  const cx2 = target.x - dx * curvature;
  const cy2 = target.y - dy * 0.1;

  return `M ${source.x} ${source.y} C ${cx1} ${cy1}, ${cx2} ${cy2}, ${target.x} ${target.y}`;
}
