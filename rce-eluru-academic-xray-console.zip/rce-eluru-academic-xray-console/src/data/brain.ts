export interface DepartmentBrainNode {
  id: 'CSE' | 'AIML' | 'ECE' | 'EEE' | 'MECH' | 'CIVIL';
  fullName: string;
  nbaAccredited: boolean;
  intake: number;
  facultyCount: number;
  labsCount: number;
  patentsCount: number;
  rdFundingLakhs: number;
  placementRate: number;
}

export const RCE_BRAIN_DEPARTMENTS: DepartmentBrainNode[] = [
  { id: 'CSE', fullName: 'Computer Science & Engineering', nbaAccredited: true, intake: 240, facultyCount: 48, labsCount: 16, patentsCount: 44, rdFundingLakhs: 142.5, placementRate: 93.8 },
  { id: 'AIML', fullName: 'Emerging Technologies (AI & ML, Data Science, IoT, Cyber Security)', nbaAccredited: true, intake: 180, facultyCount: 28, labsCount: 10, patentsCount: 31, rdFundingLakhs: 96.0, placementRate: 91.5 },
  { id: 'ECE', fullName: 'Electronics & Communication Engineering', nbaAccredited: true, intake: 180, facultyCount: 42, labsCount: 16, patentsCount: 36, rdFundingLakhs: 88.0, placementRate: 88.6 },
  { id: 'EEE', fullName: 'Electrical & Electronics Engineering', nbaAccredited: true, intake: 120, facultyCount: 30, labsCount: 12, patentsCount: 19, rdFundingLakhs: 54.0, placementRate: 84.2 },
  { id: 'MECH', fullName: 'Mechanical Engineering', nbaAccredited: true, intake: 120, facultyCount: 26, labsCount: 10, patentsCount: 14, rdFundingLakhs: 32.5, placementRate: 81.5 },
  { id: 'CIVIL', fullName: 'Civil Engineering', nbaAccredited: true, intake: 60, facultyCount: 20, labsCount: 8, patentsCount: 11, rdFundingLakhs: 21.0, placementRate: 79.8 },
];
