export interface AcademicLifecycleStage {
  id: string;
  stepNumber: string;
  phase: string;
  title: string;
  semesterWindow: string;
  cohort: number;
  passRate: number;
}

export const RCE_LIFECYCLE_TREE: AcademicLifecycleStage[] = [
  { id: 'ADM', stepNumber: '01', phase: 'ADMISSIONS', title: 'EAPCET / ECET Admissions & Parichay Orientation', semesterWindow: 'Year 1 • Sem I', cohort: 840, passRate: 100 },
  { id: 'CIE', stepNumber: '02', phase: 'MID EXAMS', title: 'Continuous Internal Evaluation (Mid-I & Mid-II)', semesterWindow: 'Sem I – VII', cohort: 822, passRate: 94.8 },
  { id: 'LAB', stepNumber: '03', phase: 'LAB EXTERNALS', title: '70+ Labs Practicals & Autonomous Lab Externals', semesterWindow: 'Sem I – VII', cohort: 814, passRate: 97.2 },
  { id: 'CRT', stepNumber: '04', phase: 'T&P BOOTCAMP', title: 'Pre-Placement Coding & Soft-Skills Bootcamp', semesterWindow: 'Sem III – VII', cohort: 795, passRate: 92.4 },
  { id: 'OUT', stepNumber: '05', phase: 'OUTCOMES', title: 'Campus Placements (610+ Offers) & Higher Studies', semesterWindow: 'Year 4 • Sem VII–VIII', cohort: 776, passRate: 91.6 },
];
