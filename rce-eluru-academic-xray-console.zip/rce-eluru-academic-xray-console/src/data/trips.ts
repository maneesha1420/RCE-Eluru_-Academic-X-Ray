export interface PlacementDriveItem {
  id: string;
  company: string;
  role: string;
  ctcRange: string;
  offers: number;
  minCgpa: number;
}

export const RCE_PLACEMENT_TRIPS: PlacementDriveItem[] = [
  { id: 'ACC', company: 'Accenture', role: 'Advanced App Engineering Analyst & ASE', ctcRange: '4.50 – 6.50 LPA', offers: 154, minCgpa: 6.5 },
  { id: 'TCS', company: 'TCS (Prime / Digital / Ninja)', role: 'Prime Digital & Systems Engineer', ctcRange: '3.36 – 9.00 LPA', offers: 168, minCgpa: 6.0 },
  { id: 'INFY', company: 'Infosys', role: 'Specialist Programmer & Systems Engineer', ctcRange: '3.60 – 9.50 LPA', offers: 118, minCgpa: 6.5 },
  { id: 'ENZEN', company: 'Enzen Global Solutions', role: 'Graduate Engineer Trainee (Energy & Smart Grid)', ctcRange: '5.20 – 7.00 LPA', offers: 42, minCgpa: 7.0 },
  { id: 'CORE', company: 'Formonic Tech, Wipro & TATA MOU Drives', role: 'Project Engineer, Structural BIM & VLSI Trainee', ctcRange: '3.80 – 6.00 LPA', offers: 128, minCgpa: 6.2 },
];
