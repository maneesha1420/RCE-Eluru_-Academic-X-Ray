export interface InstitutionalAuditItem {
  id: string;
  criterionCode: string;
  pillar: string;
  metricValue: string;
  complianceScore: number;
}

export const RCE_CHECKUP_METRICS: InstitutionalAuditItem[] = [
  { id: 'NAAC', criterionCode: 'CRITERION I–VII', pillar: 'NAAC A+ Accreditation (Upgraded from B++)', metricValue: 'NAAC A+ Grade (CGPA > 3.26)', complianceScore: 98 },
  { id: 'NBA', criterionCode: 'NBA TIER-I/II OBE', pillar: '5 Core B.Tech Programs NBA Accredited', metricValue: 'CSE, ECE, EEE, MECH, CIVIL', complianceScore: 95 },
  { id: 'RD', criterionCode: 'IQAC R&D AUDIT', pillar: 'Patents, Sponsored Grants & Publications', metricValue: '155 Patents • ₹4.34 Cr • 640+ Papers', complianceScore: 93 },
  { id: 'INFRA', criterionCode: 'GREEN & INFRA AUDIT', pillar: '13-Acre Modern Campus & Central Library', metricValue: '70+ Labs • 27,300+ Volumes', complianceScore: 96 },
];
