export const RCE_MEMORY_STORE = {
  centralLibraryVolumes: 27300,
  scopusAndIeeePublications: 640,
  patentsFiledAndPublished: 155,
  autonomousRegulations: ['R20', 'R23'],
  digitalErpModules: ['Autonomous Exam Cell', 'OBE CO-PO Attainment', 'Parent SMS Mentoring', 'GO Ms No 66 Scholarships'],
};
