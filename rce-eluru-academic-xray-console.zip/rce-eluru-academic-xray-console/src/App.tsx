import React, { useState, useMemo, useEffect, useRef } from 'react';
import {
  Zap,
  Map as MapIcon,
  Star,
  Cpu,
  GitBranch,
  ShieldCheck,
  Briefcase,
  Database,
  Code2,
  Play,
  Pause,
  ChevronRight,
  ArrowLeft,
  CheckCircle2,
  Sparkles,
  Award,
  BookOpen,
  Users,
  Building2,
  Terminal,
  Copy,
  Check,
  Eye,
  Layers,
  Search,
  Filter,
  ExternalLink,
  GraduationCap,
  Activity
} from 'lucide-react';

// ============================================================================
// 1. CORE RCE ELURU DATA STORES (src/data/brain.ts, tree.ts, checkup.ts, trips.ts)
//    Developed by Maneesha L.L.S. — Ramachandra College of Engineering, Eluru
// ============================================================================

interface CurriculumCourse {
  code: string;
  title: string;
  sem: string;
  credits: number;
  lab: boolean;
  obe: string;
  tools: string[];
}

interface DepartmentNode {
  id: 'CSE' | 'ECE' | 'EEE' | 'MECH' | 'CIVIL' | 'AIML';
  shortName: string;
  fullName: string;
  nbaStatus: string;
  intake: number;
  faculty: number;
  labs: number;
  patents: number;
  rdFundingLakhs: number;
  placementRate: number;
  color: string;
  glow: string;
  angleDeg: number;
  description: string;
  courses: CurriculumCourse[];
}

const RCE_BRAIN_DATA: DepartmentNode[] = [
  {
    id: 'CSE',
    shortName: 'CSE Core',
    fullName: 'Computer Science & Engineering (NBA Accredited)',
    nbaStatus: 'NBA Accredited • Autonomous R23',
    intake: 240,
    faculty: 48,
    labs: 16,
    patents: 44,
    rdFundingLakhs: 142.5,
    placementRate: 93.8,
    color: '#38bdf8',
    glow: 'rgba(56, 189, 248, 0.35)',
    angleDeg: -60,
    description:
      'Flagship computing department at RCE Eluru powering full-stack engineering, cloud-native systems, and enterprise placement readiness.',
    courses: [
      {
        code: 'R23CS201',
        title: 'Advanced Data Structures & Graph Algorithms',
        sem: 'Sem III',
        credits: 4,
        lab: true,
        obe: 'PO1, PO2, PSO1',
        tools: ['C++20', 'LeetCode Enterprise', 'GDB', 'Linux']
      },
      {
        code: 'R23CS302',
        title: 'Full-Stack React, TypeScript & Cloud Microservices',
        sem: 'Sem V',
        credits: 4,
        lab: true,
        obe: 'PO3, PO5, PSO2',
        tools: ['React 18', 'TypeScript', 'Vite', 'Docker', 'AWS']
      },
      {
        code: 'R23CS401',
        title: 'Distributed Systems & DevSecOps Pipelines',
        sem: 'Sem VII',
        credits: 3,
        lab: false,
        obe: 'PO4, PO11, PSO2',
        tools: ['Kubernetes', 'GitHub Actions', 'Terraform']
      }
    ]
  },
  {
    id: 'AIML',
    shortName: 'AI & ML / IoT / CS',
    fullName: 'Emerging Technologies (AI & ML, Data Science, IoT, Cyber Security)',
    nbaStatus: 'AICTE Approved • R23 Autonomous Track',
    intake: 180,
    faculty: 28,
    labs: 10,
    patents: 31,
    rdFundingLakhs: 96.0,
    placementRate: 91.5,
    color: '#c084fc',
    glow: 'rgba(192, 132, 252, 0.35)',
    angleDeg: 0,
    description:
      'Specialized next-generation branches at RCE Eluru covering Deep Learning, Agentic AI, Smart IoT Gateways, and Zero-Trust Security.',
    courses: [
      {
        code: 'R23AI204',
        title: 'Neural Networks, Transformers & LLM Agents',
        sem: 'Sem V',
        credits: 4,
        lab: true,
        obe: 'PO1, PO4, PSO1',
        tools: ['PyTorch', 'CUDA', 'HuggingFace', 'LangGraph']
      },
      {
        code: 'R23CY301',
        title: 'Ethical Hacking, SOC Telemetry & Cryptography',
        sem: 'Sem VI',
        credits: 4,
        lab: true,
        obe: 'PO2, PO6, PSO2',
        tools: ['Wireshark', 'Metasploit', 'SIEM', ' Kali']
      }
    ]
  },
  {
    id: 'ECE',
    shortName: 'ECE',
    fullName: 'Electronics & Communication Engineering (NBA Accredited)',
    nbaStatus: 'NBA Accredited • Autonomous R23',
    intake: 180,
    faculty: 42,
    labs: 16,
    patents: 36,
    rdFundingLakhs: 88.0,
    placementRate: 88.6,
    color: '#fbbf24',
    glow: 'rgba(251, 191, 36, 0.35)',
    angleDeg: 60,
    description:
      'Focuses on ASIC/FPGA VLSI design, 5G RF front-ends, embedded RTOS architectures, and industrial IoT sensor networks.',
    courses: [
      {
        code: 'R23EC202',
        title: 'CMOS VLSI Design & Verilog HDL Synthesis',
        sem: 'Sem IV',
        credits: 4,
        lab: true,
        obe: 'PO1, PO3, PSO1',
        tools: ['Cadence Virtuoso', 'Xilinx Vivado', 'Verilog']
      },
      {
        code: 'R23EC305',
        title: 'ARM Cortex Embedded RTOS & Edge Signal Processing',
        sem: 'Sem VI',
        credits: 4,
        lab: true,
        obe: 'PO2, PO5, PSO2',
        tools: ['STM32Cube', 'FreeRTOS', 'MATLAB DSP']
      }
    ]
  },
  {
    id: 'EEE',
    shortName: 'EEE',
    fullName: 'Electrical & Electronics Engineering (NBA Accredited)',
    nbaStatus: 'NBA Accredited • Autonomous R23',
    intake: 120,
    faculty: 30,
    labs: 12,
    patents: 19,
    rdFundingLakhs: 54.0,
    placementRate: 84.2,
    color: '#34d399',
    glow: 'rgba(52, 211, 153, 0.35)',
    angleDeg: 120,
    description:
      'Drives smart microgrid automation, EV battery management systems (BMS), and high-efficiency power electronics.',
    courses: [
      {
        code: 'R23EE204',
        title: 'Solid-State Power Converters & Smart Grids',
        sem: 'Sem IV',
        credits: 4,
        lab: true,
        obe: 'PO1, PO4, PSO1',
        tools: ['MATLAB Simulink', 'PSCAD', 'dSPACE']
      },
      {
        code: 'R23EE302',
        title: 'Electric Vehicle Traction & BMS Telemetry',
        sem: 'Sem VI',
        credits: 3,
        lab: true,
        obe: 'PO3, PO7, PSO2',
        tools: ['ANSYS Maxwell', 'CAN Bus Analyzer']
      }
    ]
  },
  {
    id: 'MECH',
    shortName: 'MECH',
    fullName: 'Mechanical Engineering (NBA Accredited)',
    nbaStatus: 'NBA Accredited • Autonomous R23',
    intake: 120,
    faculty: 26,
    labs: 10,
    patents: 14,
    rdFundingLakhs: 32.5,
    placementRate: 81.5,
    color: '#f472b6',
    glow: 'rgba(244, 114, 182, 0.35)',
    angleDeg: 180,
    description:
      'Integrates digital-twin CAD/CAM/CAE simulation, additive manufacturing, robotics, and thermal systems engineering.',
    courses: [
      {
        code: 'R23ME203',
        title: 'Finite Element Analysis & Digital Twin CAD/CAM',
        sem: 'Sem IV',
        credits: 4,
        lab: true,
        obe: 'PO1, PO5, PSO1',
        tools: ['ANSYS Workbench', 'SolidWorks', 'Mastercam']
      },
      {
        code: 'R23ME306',
        title: 'Industrial Robotics & Mechatronic Actuation',
        sem: 'Sem VI',
        credits: 4,
        lab: true,
        obe: 'PO3, PO9, PSO2',
        tools: ['ROS2', 'PLC Ladder', 'Pneumatics Sim']
      }
    ]
  },
  {
    id: 'CIVIL',
    shortName: 'CIVIL',
    fullName: 'Civil Engineering (NBA Accredited)',
    nbaStatus: 'NBA Accredited • Autonomous R23',
    intake: 60,
    faculty: 20,
    labs: 8,
    patents: 11,
    rdFundingLakhs: 21.0,
    placementRate: 79.8,
    color: '#fb923c',
    glow: 'rgba(251, 146, 60, 0.35)',
    angleDeg: -120,
    description:
      'Pioneers sustainable green infrastructure, BIM structural modeling, and geospatial remote sensing across Andhra Pradesh.',
    courses: [
      {
        code: 'R23CE201',
        title: 'Seismic Structural Design & STAAD.Pro BIM',
        sem: 'Sem IV',
        credits: 4,
        lab: true,
        obe: 'PO1, PO3, PSO1',
        tools: ['STAAD.Pro', 'Autodesk Revit', 'ETABS']
      },
      {
        code: 'R23CE304',
        title: 'QGIS Geospatial Surveying & Green Smart Cities',
        sem: 'Sem VI',
        credits: 3,
        lab: true,
        obe: 'PO6, PO7, PSO2',
        tools: ['QGIS', 'Total Station', 'AutoCAD Civil 3D']
      }
    ]
  }
];

interface LifecycleStage {
  id: string;
  stepNumber: string;
  phase: string;
  title: string;
  window: string;
  rule: string;
  cohort: number;
  passRate: number;
  color: string;
  deliverables: string[];
}

const RCE_TREE_DATA: LifecycleStage[] = [
  {
    id: 'ADM',
    stepNumber: '01',
    phase: 'ADMISSIONS & INDUCTION',
    title: 'EAPCET / ECET Admissions & Parichay Orientation',
    window: 'Year 1 • Sem I Entry',
    rule: 'AP EAPCET Merit / Category-B + GO Ms No 66 Fee Reimbursement & RCE Merit Scholarships',
    cohort: 840,
    passRate: 100,
    color: '#38bdf8',
    deliverables: [
      'JNTUK Autonomous Roll Number & Digital ERP Provisioning',
      'Ramachandra Laptop & Merit Scholarship Allocation (Up to ₹50 Lakhs Pool)',
      'Freshmen Engineering Department (FED) Bridge Bootcamp'
    ]
  },
  {
    id: 'CIE',
    stepNumber: '02',
    phase: 'MID EXAMS (CIE)',
    title: 'Continuous Internal Evaluation (Mid-I & Mid-II)',
    window: 'Semesters I – VII',
    rule: '80% Best Mid + 20% Other Mid + Online Quiz & CO-Mapped Assignments (30 Marks CIE)',
    cohort: 822,
    passRate: 94.8,
    color: '#c084fc',
    deliverables: [
      'Bloom’s Taxonomy Level-4/5 Analytical Question Bank',
      'Automated Parent Mentorship Telemetry & Attendance Alerts (>=75%)',
      'Target-Zero-Backlog Remedial Tutorials'
    ]
  },
  {
    id: 'LAB',
    stepNumber: '03',
    phase: 'LAB EXTERNALS',
    title: '70+ Laboratories Practicals & Autonomous Lab Externals',
    window: 'Semesters I – VII',
    rule: '30 Marks Day-to-Day Lab Execution + 70 Marks End-Semester External Examiner Viva',
    cohort: 814,
    passRate: 97.2,
    color: '#fbbf24',
    deliverables: [
      'Live Code / VLSI / CAD / Power Systems Hardware Demonstration',
      'External University Panel Viva-Voce & GitHub Artifact Sign-off',
      'TATA & RelianceMOU Industry Sandbox Mini-Projects'
    ]
  },
  {
    id: 'CRT',
    stepNumber: '04',
    phase: 'T&P BOOTCAMP',
    title: 'Pre-Placement Coding & Soft-Skills Bootcamp',
    window: 'From Year 2 (Sem III – VII)',
    rule: 'Mandatory DSA, Aptitude, GD & Company-Specific Mock Test Clearance',
    cohort: 795,
    passRate: 92.4,
    color: '#34d399',
    deliverables: [
      'Full-Stack & Competitive Coding Sprints (TCS NQT, HackWithInfy, Accenture)',
      '1-on-1 Mock Technical & HR Panels with Industry Mentors',
      '6-Month Mandatory Industry Internship Mapping'
    ]
  },
  {
    id: 'OUT',
    stepNumber: '05',
    phase: 'FINAL PLACEMENTS & R&D',
    title: 'Campus Placements (610+ Offers) & Higher Studies / Patents',
    window: 'Year 4 • Sem VII – VIII',
    rule: 'CGPA >= 6.5 for Tier-1 MNC Drives | Capstone Thesis + Patent/Scopus Publication',
    cohort: 776,
    passRate: 91.6,
    color: '#f472b6',
    deliverables: [
      '610+ Placement Offers across 50+ MNCs (Accenture, TCS, Infosys, Wipro, Enzen)',
      'Student Co-Authored Patents contributing to RCE’s 155+ Patent Portfolio',
      'GATE / GRE / MS Overseas & 10,000+ RCE Alumni Network Induction'
    ]
  }
];

interface CheckupMetric {
  id: string;
  code: string;
  pillar: string;
  title: string;
  metricValue: string;
  benchmark: string;
  score: number;
  badge: string;
  details: string;
}

const RCE_CHECKUP_DATA: CheckupMetric[] = [
  {
    id: 'NAAC',
    code: 'CRITERION I–VII',
    pillar: 'NAAC A+ ACCREDITATION',
    title: 'Upgraded from NAAC B++ to NAAC A+ Grade',
    metricValue: 'NAAC A+ Grade',
    benchmark: 'Autonomous Institutional Excellence (CGPA > 3.26)',
    score: 98,
    badge: 'VERIFIED A+',
    details:
      'Permanently affiliated to JNTUK Kakinada with full Autonomous status, digital exam cell, and OBE Gold Band recognition.'
  },
  {
    id: 'NBA',
    code: 'NBA TIER-I/II OBE',
    pillar: '5 CORE PROGRAMS NBA ACCREDITED',
    title: 'B.Tech CSE, ECE, EEE, MECH & CIVIL NBA Compliance',
    metricValue: '5 / 5 Core Branches',
    benchmark: 'CO-PO-PSO Attainment >= 2.45 / 3.00',
    score: 95,
    badge: '2nd CYCLE NBA',
    details:
      'Continuous Outcome-Based Education (OBE) tracking across every course, lab external, and capstone project.'
  },
  {
    id: 'RESEARCH',
    code: 'IQAC R&D AUDIT',
    pillar: 'PATENTS, PUBLICATIONS & GRANTS',
    title: 'Faculty Research Output & Sponsored Projects',
    metricValue: '155 Patents • ₹4.34 Cr',
    benchmark: '640+ Scopus/IEEE Publications • 190+ Faculty',
    score: 93,
    badge: 'GOLD BAND R&D',
    details:
      'AICTE, DST, and industry-funded research laboratories with active student-faculty patent co-authorship.'
  },
  {
    id: 'CAMPUS',
    code: 'GREEN & INFRA AUDIT',
    pillar: '13-ACRE MODERN CAMPUS',
    title: 'Laboratories, Central Library & Green Ranking',
    metricValue: '70+ Labs • 27,300+ Books',
    benchmark: 'Gold Band in Sustainable Institutions Green Rankings',
    score: 96,
    badge: 'GRADE-A GOLD',
    details:
      '24/7 CCTV secure campus in Vatluru, Eluru with gigabit LAN, smart classrooms, and 24+ student innovation clubs.'
  }
];

interface PlacementDrive {
  id: string;
  company: string;
  category: string;
  role: string;
  ctc: string;
  branches: string[];
  minCgpa: number;
  backlogsAllowed: number;
  offers: number;
  registered: number;
  highlightQuote: string;
}

const RCE_TRIPS_DATA: PlacementDrive[] = [
  {
    id: 'DRV-ACC',
    company: 'Accenture',
    category: 'Tier-1 Global Consulting & AI',
    role: 'Advanced App Engineering Analyst & ASE',
    ctc: '4.50 – 6.50 LPA',
    branches: ['CSE', 'AIML', 'ECE', 'EEE', 'MECH', 'CIVIL'],
    minCgpa: 6.5,
    backlogsAllowed: 0,
    offers: 154,
    registered: 520,
    highlightQuote:
      'Rigorous autonomous curriculum and mock coding bootcamps from 2nd year drove record Accenture selections.'
  },
  {
    id: 'DRV-TCS',
    company: 'TCS (Prime / Digital / Ninja)',
    category: 'MNC IT Services Leader',
    role: 'Prime Digital Engineer & Systems Engineer',
    ctc: '3.36 – 9.00 LPA',
    branches: ['CSE', 'AIML', 'ECE', 'EEE', 'MECH', 'CIVIL'],
    minCgpa: 6.0,
    backlogsAllowed: 0,
    offers: 168,
    registered: 610,
    highlightQuote:
      'Dedicated TCS NQT training tracks across all 5 NBA-accredited branches ensured high Digital & Prime conversions.'
  },
  {
    id: 'DRV-INFY',
    company: 'Infosys',
    category: 'Digital & Cloud Transformation',
    role: 'Specialist Programmer & Systems Engineer',
    ctc: '3.60 – 9.50 LPA',
    branches: ['CSE', 'AIML', 'ECE', 'EEE'],
    minCgpa: 6.5,
    backlogsAllowed: 0,
    offers: 118,
    registered: 430,
    highlightQuote:
      'Pre-placement training from second year enabled strong performance in HackWithInfy and technical interviews.'
  },
  {
    id: 'DRV-ENZEN',
    company: 'Enzen Global Solutions',
    category: 'Core Energy & Smart Grid Product',
    role: 'Graduate Engineer Trainee (Energy & Digital)',
    ctc: '5.20 – 7.00 LPA',
    branches: ['CSE', 'ECE', 'EEE'],
    minCgpa: 7.0,
    backlogsAllowed: 0,
    offers: 42,
    registered: 215,
    highlightQuote:
      'High entry-level CTC core engineering roles combining domain power systems with cloud analytics.'
  },
  {
    id: 'DRV-CORE',
    company: 'Formonic Tech, Wipro & TATA MOU Drives',
    category: 'Core Engineering & Enterprise',
    role: 'Project Engineer, Structural BIM & VLSI Trainee',
    ctc: '3.80 – 6.00 LPA',
    branches: ['CSE', 'ECE', 'EEE', 'MECH', 'CIVIL'],
    minCgpa: 6.2,
    backlogsAllowed: 1,
    offers: 128,
    registered: 490,
    highlightQuote:
      'Direct industry exposure through MOUs with TATA and Reliance HR Solutions plus core civil/mechanical placements.'
  }
];

interface AnatomicalHotspot {
  id: 'brain' | 'checkup' | 'tree' | 'trips' | 'memory' | 'blueprint';
  label: string;
  organName: string;
  fileMapping: string;
  cx: number;
  cy: number;
  color: string;
  summary: string;
  partCount: number;
  toolCount: number;
}

const RAY_ANATOMY_HOTSPOTS: AnatomicalHotspot[] = [
  {
    id: 'brain',
    label: 'Neural Core → RCE Departments',
    organName: 'BRAIN.TS • 6 Dept Clusters',
    fileMapping: 'src/data/brain.ts & src/scenes/brain.tsx',
    cx: 220,
    cy: 118,
    color: '#38bdf8',
    summary: 'Maps CSE, AI/ML/IoT/CS, ECE, EEE, MECH & CIVIL curricula, 70+ labs, and OBE outcomes.',
    partCount: 38,
    toolCount: 96
  },
  {
    id: 'checkup',
    label: 'Heart Monitor → NAAC A+ & NBA Audit',
    organName: 'CHECKUP.TS • IQAC Telemetry',
    fileMapping: 'src/data/checkup.ts & src/scenes/checkup.tsx',
    cx: 194,
    cy: 248,
    color: '#f43f5e',
    summary: 'Tracks NAAC A+ grade, 5 NBA-accredited branches, 155 patents, and ₹4.34 Cr R&D grants.',
    partCount: 24,
    toolCount: 64
  },
  {
    id: 'tree',
    label: 'Spinal Bus → Student Lifecycle Tree',
    organName: 'TREE.TS • Sem I to VIII DAG',
    fileMapping: 'src/data/tree.ts & src/scenes/tree.tsx',
    cx: 246,
    cy: 252,
    color: '#c084fc',
    summary: 'Traces student journey: EAPCET Admissions → Mid Exams → Lab Externals → Placements.',
    partCount: 29,
    toolCount: 72
  },
  {
    id: 'memory',
    label: 'Memory Vault → Library & Autonomous ERP',
    organName: 'MEMORY.TS • 27,300+ Volumes',
    fileMapping: 'src/data/memory.ts & src/components/Ray.tsx',
    cx: 220,
    cy: 298,
    color: '#fbbf24',
    summary: 'Stores 27,300+ central library volumes, digital exam ERP records, and 640+ faculty papers.',
    partCount: 19,
    toolCount: 41
  },
  {
    id: 'trips',
    label: 'Propulsion Legs → T&P Placement Drives',
    organName: 'TRIPS.TS • 610+ Annual Offers',
    fileMapping: 'src/data/trips.ts & src/scenes/trips.tsx',
    cx: 220,
    cy: 382,
    color: '#34d399',
    summary: 'Powers 610+ placement offers across 50+ companies (Accenture, TCS, Infosys, Enzen, Wipro).',
    partCount: 25,
    toolCount: 54
  }
];

// ============================================================================
// 2. COPY-PASTEABLE REPOSITORY CODE SNIPPETS (For Developer Blueprint Drawer)
// ============================================================================

const REPO_CODE_FILES: Record<string, { path: string; lang: string; desc: string; code: string }> = {
  topbar: {
    path: 'src/components/TopBar.tsx',
    lang: 'tsx',
    desc: 'Exact Agent-Xray style TopBar rebranded for RCE Eluru with X-ray switch, 1/135 progress ring, Whole map button, and Maneesha L.L.S. credit.',
    code: `import React from 'react';

interface TopBarProps {
  discoveredCount: number;
  totalParts?: number;
  xrayOn: boolean;
  onToggleXray: () => void;
  onOpenWholeMap: () => void;
  onOpenCredits: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  discoveredCount,
  totalParts = 135,
  xrayOn,
  onToggleXray,
  onOpenWholeMap,
  onOpenCredits,
}) => {
  return (
    <header className="rce-xray-topbar">
      <div className="brand-left">
        <span className="bot-logo-badge">🤖</span>
        <span className="brand-title">
          RCE <strong className="accent-cyan">Xray</strong>
        </span>
        <span className="brand-sub-pill">ELURU • NAAC A+</span>
      </div>

      <div className="controls-right">
        <div className="progress-counter">
          <span className="ring-dot" />
          <span>{discoveredCount}/{totalParts}</span>
        </div>

        <button
          type="button"
          className={\`xray-switch-pill \${xrayOn ? 'is-on' : ''}\`}
          onClick={onToggleXray}
        >
          <span>⚡ X-ray</span>
          <span className="switch-track">
            <span className="switch-thumb" />
          </span>
        </button>

        <button type="button" className="map-pill-btn" onClick={onOpenWholeMap}>
          🗺️ Whole map
        </button>

        <button type="button" className="credit-pill-btn" onClick={onOpenCredits}>
          ⭐ Developed by Maneesha L.L.S.
        </button>
      </div>
    </header>
  );
};`
  },
  brainData: {
    path: 'src/data/brain.ts',
    lang: 'typescript',
    desc: 'Maps RCE Eluru departments (CSE, AI/ML/IoT/CS, ECE, EEE, MECH, CIVIL), NBA accreditation, and autonomous curriculum.',
    code: `export interface DepartmentBrainNode {
  id: 'CSE' | 'AIML' | 'ECE' | 'EEE' | 'MECH' | 'CIVIL';
  fullName: string;
  nbaAccredited: boolean;
  intake: number;
  facultyCount: number;
  labsCount: number;
  patentsCount: number;
  placementRate: number;
}

export const RCE_DEPARTMENTS_BRAIN: DepartmentBrainNode[] = [
  { id: 'CSE', fullName: 'Computer Science & Engineering', nbaAccredited: true, intake: 240, facultyCount: 48, labsCount: 16, patentsCount: 44, placementRate: 93.8 },
  { id: 'AIML', fullName: 'AI & ML, Data Science, IoT & Cyber Security', nbaAccredited: true, intake: 180, facultyCount: 28, labsCount: 10, patentsCount: 31, placementRate: 91.5 },
  { id: 'ECE', fullName: 'Electronics & Communication Engineering', nbaAccredited: true, intake: 180, facultyCount: 42, labsCount: 16, patentsCount: 36, placementRate: 88.6 },
  { id: 'EEE', fullName: 'Electrical & Electronics Engineering', nbaAccredited: true, intake: 120, facultyCount: 30, labsCount: 12, patentsCount: 19, placementRate: 84.2 },
  { id: 'MECH', fullName: 'Mechanical Engineering', nbaAccredited: true, intake: 120, facultyCount: 26, labsCount: 10, patentsCount: 14, placementRate: 81.5 },
  { id: 'CIVIL', fullName: 'Civil Engineering', nbaAccredited: true, intake: 60, facultyCount: 20, labsCount: 8, patentsCount: 11, placementRate: 79.8 },
];`
  },
  tourScript: {
    path: 'scripts/tour.mjs & video/make.mjs',
    lang: 'javascript',
    desc: 'Automated Playwright + FFmpeg management report generator with hardcoded "Developed by Maneesha L.L.S." watermark.',
    code: `// scripts/tour.mjs — Automated RCE X-Ray Scene Capture
import { chromium } from 'playwright';
import { execFileSync } from 'node:child_process';

async function generateRceManagementVideo() {
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage({ viewport: { width: 1920, height: 1080 } });
  await page.goto('http://localhost:5173', { waitUntil: 'networkidle' });

  // 1. Capture Hero & Turn on the X-ray
  await page.screenshot({ path: 'video/frames/01_hero.png' });
  await page.click('button:has-text("Turn on the X-ray")');
  await page.waitForTimeout(600);
  await page.screenshot({ path: 'video/frames/02_xray_active.png' });

  await browser.close();

  // 2. Render MP4 with Maneesha L.L.S. Watermark
  execFileSync('ffmpeg', [
    '-y', '-framerate', '0.5', '-pattern_type', 'glob', '-i', 'video/frames/frame_%03d.png',
    '-vf', "drawbox=x=0:y=ih-52:w=iw:h=52:color=#070b14@0.9:t=fill,drawtext=text='RCE Eluru - Academic X-Ray Analytics Console  |  Developed by Maneesha L.L.S.':x=40:y=h-34:fontsize=22:fontcolor=#fbbf24",
    '-c:v', 'libx264', '-pix_fmt', 'yuv420p', 'video/output/rce_xray_report.mp4'
  ]);
}
generateRceManagementVideo();`
  }
};

// ============================================================================
// 3. MAIN INTERACTIVE APPLICATION COMPONENT
// ============================================================================

export default function App() {
  // Core state matching https://mfahadakbar.github.io/agent-xray/
  const [xrayOn, setXrayOn] = useState<boolean>(false);
  const [activeScene, setActiveScene] = useState<
    'hero' | 'brain' | 'tree' | 'checkup' | 'trips' | 'blueprint'
  >('hero');
  const [selectedDeptId, setSelectedDeptId] = useState<DepartmentNode['id']>('CSE');
  const [selectedStageId, setSelectedStageId] = useState<string>('ADM');
  const [selectedDriveBranch, setSelectedDriveBranch] = useState<string>('ALL');
  const [hoveredOrgan, setHoveredOrgan] = useState<AnatomicalHotspot | null>(null);
  const [discoveredIds, setDiscoveredIds] = useState<string[]>(['ray-intro']);
  const [wholeMapOpen, setWholeMapOpen] = useState<boolean>(false);
  const [creditsModalOpen, setCreditsModalOpen] = useState<boolean>(false);
  const [autoTourRunning, setAutoTourRunning] = useState<boolean>(false);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Mouse cursor tracking over Ray SVG for the "Move your mouse over Ray to peek" X-Ray lens!
  const svgRef = useRef<SVGSVGElement | null>(null);
  const [lensPos, setLensPos] = useState<{ x: number; y: number; active: boolean }>({
    x: 220,
    y: 230,
    active: false
  });

  const markDiscovered = (id: string) => {
    setDiscoveredIds((prev) => (prev.includes(id) ? prev : [...prev, id]));
  };

  // Count scales organically toward 135 as user explores organs, departments, stages, and map
  const partsCount = useMemo(() => {
    return Math.min(135, 1 + (discoveredIds.length - 1) * 9 + (xrayOn ? 18 : 0));
  }, [discoveredIds.length, xrayOn]);

  // Automated Management Video Tour Simulation (`scripts/tour.mjs` live preview)
  useEffect(() => {
    if (!autoTourRunning) return;
    const sequence: Array<() => void> = [
      () => {
        setXrayOn(true);
        setActiveScene('hero');
        markDiscovered('tour-xray');
      },
      () => {
        setActiveScene('brain');
        setSelectedDeptId('CSE');
        markDiscovered('tour-brain-cse');
      },
      () => {
        setActiveScene('brain');
        setSelectedDeptId('ECE');
        markDiscovered('tour-brain-ece');
      },
      () => {
        setActiveScene('tree');
        setSelectedStageId('LAB');
        markDiscovered('tour-tree');
      },
      () => {
        setActiveScene('checkup');
        markDiscovered('tour-checkup');
      },
      () => {
        setActiveScene('trips');
        markDiscovered('tour-trips');
      },
      () => {
        setActiveScene('hero');
        setAutoTourRunning(false);
      }
    ];

    let step = 0;
    sequence[0]();
    const timer = window.setInterval(() => {
      step += 1;
      if (step < sequence.length) {
        sequence[step]();
      } else {
        window.clearInterval(timer);
      }
    }, 2800);

    return () => window.clearInterval(timer);
  }, [autoTourRunning]);

  const handleSvgMouseMove = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!svgRef.current) return;
    const rect = svgRef.current.getBoundingClientRect();
    const scaleX = 440 / rect.width;
    const scaleY = 480 / rect.height;
    const x = (e.clientX - rect.left) * scaleX;
    const y = (e.clientY - rect.top) * scaleY;
    setLensPos({ x, y, active: true });
    markDiscovered('hover-peek');
  };

  const handleCopyCode = (key: string, text: string) => {
    try {
      navigator.clipboard.writeText(text);
    } catch {
      const textarea = document.createElement('textarea');
      textarea.value = text;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand('copy');
      document.body.removeChild(textarea);
    }
    setCopiedKey(key);
    window.setTimeout(() => setCopiedKey(null), 1800);
  };

  const selectedDepartment = useMemo(
    () => RCE_BRAIN_DATA.find((d) => d.id === selectedDeptId) || RCE_BRAIN_DATA[0],
    [selectedDeptId]
  );

  const selectedLifecycle = useMemo(
    () => RCE_TREE_DATA.find((s) => s.id === selectedStageId) || RCE_TREE_DATA[0],
    [selectedStageId]
  );

  const filteredDrives = useMemo(() => {
    if (selectedDriveBranch === 'ALL') return RCE_TRIPS_DATA;
    return RCE_TRIPS_DATA.filter((d) => d.branches.includes(selectedDriveBranch));
  }, [selectedDriveBranch]);

  const showXrayInterior = xrayOn || lensPos.active;

  return (
    <div
      className="min-h-screen w-full flex flex-col justify-between text-slate-100 select-none overflow-x-hidden"
      style={{
        backgroundColor: '#070b14',
        backgroundImage:
          'radial-gradient(circle at 50% 42%, rgba(28, 52, 104, 0.28) 0%, rgba(7, 11, 20, 0) 62%), radial-gradient(rgba(148, 163, 184, 0.14) 1px, transparent 1px)',
        backgroundSize: '100% 100%, 26px 26px',
        fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, sans-serif"
      }}
    >
      {/* ===================================================================
          TOP BAR (Matches Agent Xray Screenshot + RCE Eluru & Maneesha Credits)
         =================================================================== */}
      <header className="w-full h-16 px-4 sm:px-7 flex items-center justify-between border-b border-slate-800/80 bg-[#070b14]/90 backdrop-blur-md sticky top-0 z-40">
        {/* Left: Robot Icon + RCE Xray Brand */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => setActiveScene('hero')}
            className="flex items-center gap-2.5 group text-left focus:outline-none"
          >
            {/* Mini Robot Logo matching top-left of screenshot */}
            <div className="w-8 h-8 rounded-lg bg-slate-900 border border-slate-700/80 flex items-center justify-center shadow-inner group-hover:border-sky-400 transition-colors">
              <svg viewBox="0 0 32 32" className="w-6 h-6">
                <line x1="16" y1="3" x2="16" y2="7" stroke="#94a3b8" strokeWidth="2" />
                <circle cx="16" cy="3" r="2" fill="#f472b6" />
                <rect x="6" y="7" width="20" height="16" rx="5" fill="#e2e8f0" />
                <rect x="9" y="10" width="14" height="10" rx="3" fill="#0f172a" />
                <circle cx="13" cy="15" r="2" fill="#38bdf8" />
                <circle cx="19" cy="15" r="2" fill="#38bdf8" />
              </svg>
            </div>
            <div className="flex items-baseline gap-1.5">
              <span className="text-lg font-extrabold tracking-tight text-white">RCE</span>
              <span className="text-lg font-extrabold tracking-tight text-sky-400">Xray</span>
              <span className="hidden md:inline-block ml-2 text-[10px] font-mono uppercase tracking-widest px-2 py-0.5 rounded bg-amber-500/15 text-amber-300 border border-amber-400/30">
                Eluru • NAAC A+
              </span>
            </div>
          </button>
        </div>

        {/* Center Scene Quick-Jump Pills (visible when exploring scenes or X-ray is active) */}
        <div className="hidden xl:flex items-center gap-1.5 bg-slate-900/90 border border-slate-800 rounded-full p-1">
          {[
            { id: 'hero', label: '🤖 Ray Overview' },
            { id: 'brain', label: '🧠 Brain: 6 Depts' },
            { id: 'tree', label: '🌳 Tree: Lifecycle' },
            { id: 'checkup', label: '💓 Checkup: NAAC/NBA' },
            { id: 'trips', label: '🚀 Trips: 610+ Offers' },
            { id: 'blueprint', label: '💻 Code Blueprint' }
          ].map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => {
                setActiveScene(tab.id as typeof activeScene);
                markDiscovered(`nav-${tab.id}`);
              }}
              className={`px-3 py-1 rounded-full text-xs font-semibold transition-all ${
                activeScene === tab.id
                  ? 'bg-sky-400 text-slate-950 shadow-[0_0_12px_rgba(56,189,248,0.45)]'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/70'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Right: 1/135 Counter, ⚡ X-ray Switch, 🗺️ Whole map, ⭐ Maneesha L.L.S. */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Progress Ring 1/135 */}
          <button
            type="button"
            onClick={() => setWholeMapOpen(true)}
            title="Parts inspected across RCE Eluru X-Ray"
            className="hidden sm:flex items-center gap-2 px-2.5 py-1 rounded-full text-xs font-medium text-slate-300 hover:text-white transition"
          >
            <svg className="w-4 h-4 -rotate-90" viewBox="0 0 24 24">
              <circle
                cx="12"
                cy="12"
                r="9"
                fill="none"
                stroke="#1e293b"
                strokeWidth="2.5"
              />
              <circle
                cx="12"
                cy="12"
                r="9"
                fill="none"
                stroke="#38bdf8"
                strokeWidth="2.5"
                strokeDasharray={56.5}
                strokeDashoffset={56.5 - (56.5 * partsCount) / 135}
                strokeLinecap="round"
              />
            </svg>
            <span className="font-mono text-xs text-slate-300">{partsCount}/135</span>
          </button>

          {/* ⚡ X-ray Pill Toggle Switch */}
          <button
            type="button"
            onClick={() => {
              setXrayOn((prev) => !prev);
              markDiscovered('toggle-xray-top');
            }}
            className={`flex items-center gap-2.5 px-3.5 py-1.5 rounded-full border text-xs font-semibold transition-all ${
              xrayOn
                ? 'bg-sky-500/20 border-sky-400 text-sky-200 shadow-[0_0_20px_rgba(56,189,248,0.3)]'
                : 'bg-slate-900/90 border-slate-700/80 text-slate-200 hover:border-slate-600'
            }`}
          >
            <span className="flex items-center gap-1">
              <Zap className={`w-3.5 h-3.5 ${xrayOn ? 'text-amber-400 fill-amber-400' : 'text-amber-400'}`} />
              <span>X-ray</span>
            </span>
            <span
              className={`w-8 h-4 rounded-full p-0.5 transition-colors flex items-center ${
                xrayOn ? 'bg-sky-400 justify-end' : 'bg-slate-700 justify-start'
              }`}
            >
              <span className="w-3 h-3 rounded-full bg-white shadow" />
            </span>
          </button>

          {/* 🗺️ Whole map Button */}
          <button
            type="button"
            onClick={() => {
              setWholeMapOpen(true);
              markDiscovered('open-whole-map');
            }}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-slate-900/90 border border-slate-700/80 hover:border-sky-400/60 text-xs font-semibold text-slate-200 transition-all"
          >
            <MapIcon className="w-3.5 h-3.5 text-sky-400" />
            <span className="hidden md:inline">Whole map</span>
          </button>

          {/* ⭐ Developed by Maneesha L.L.S. Pill (Replaces Star on GitHub) */}
          <button
            type="button"
            onClick={() => {
              setCreditsModalOpen(true);
              markDiscovered('open-credits');
            }}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-slate-900/95 border border-amber-400/50 hover:border-amber-300 text-xs font-semibold text-white shadow-[0_0_15px_rgba(245,183,0,0.18)] transition-all"
          >
            <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
            <span>Maneesha L.L.S.</span>
          </button>
        </div>
      </header>

      {/* ===================================================================
          AUTO-TOUR WATERMARK BANNER (When video/make.mjs simulation is active)
         =================================================================== */}
      {autoTourRunning && (
        <div className="bg-amber-500/15 border-b border-amber-400/40 px-6 py-2 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 text-amber-300 font-mono">
            <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
            <span>
              [REC • scripts/tour.mjs] Auto-generating Management Placement & NAAC A+ Briefing...
            </span>
          </div>
          <div className="flex items-center gap-4">
            <span className="font-mono text-white font-semibold">
              WATERMARK: Developed by Maneesha L.L.S.
            </span>
            <button
              type="button"
              onClick={() => setAutoTourRunning(false)}
              className="px-2.5 py-0.5 rounded bg-rose-500/20 border border-rose-400/40 text-rose-200 hover:bg-rose-500/30"
            >
              Stop Tour
            </button>
          </div>
        </div>
      )}

      {/* ===================================================================
          SCENE 0: THE ICONIC AGENT-XRAY HERO STAGE (Matches Screenshot 1:1)
         =================================================================== */}
      {activeScene === 'hero' && (
        <main className="flex-1 flex flex-col justify-center items-center px-4 sm:px-8 py-4 relative">
          <div className="max-w-6xl w-full grid grid-cols-1 lg:grid-cols-12 gap-6 items-center my-auto">
            {/* LEFT COLUMN: Headline, Copy & Glowing Cyan CTA Pill */}
            <div className="lg:col-span-4 flex flex-col items-start text-left lg:pl-4 z-10">
              <span className="text-[11px] font-bold tracking-[0.2em] uppercase text-sky-300/90 mb-3">
                RCE ELURU — ACADEMIC XRAY
              </span>

              <h1 className="text-4xl sm:text-[44px] font-extrabold leading-[1.08] tracking-tight text-white mb-5">
                How does
                <br />
                an{' '}
                <span
                  className="bg-clip-text text-transparent"
                  style={{
                    backgroundImage: 'linear-gradient(90deg, #60a5fa 0%, #c084fc 50%, #f472b6 100%)'
                  }}
                >
                  RCE campus
                </span>
                <br />
                really work?
              </h1>

              <p className="text-sm sm:text-[15px] leading-relaxed text-slate-300/90 mb-4 max-w-sm">
                You are in the right place. Here we put{' '}
                <strong className="text-white font-semibold">
                  Ramachandra College of Engineering, Eluru
                </strong>{' '}
                under the X-ray, and you get to see every single part of it.
              </p>

              <p className="text-sm sm:text-[15px] font-bold text-white leading-snug mb-7 max-w-sm">
                What each department is. Why NAAC A+ &amp; NBA matter. Which real labs &amp;
                recruiters build it.
              </p>

              {/* Glowing Pill CTA matching "⚡ Turn on the X-ray" in screenshot */}
              <div className="flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setXrayOn((prev) => !prev);
                    markDiscovered('hero-cta-xray');
                  }}
                  className="group relative inline-flex items-center gap-2.5 px-7 py-3.5 rounded-full font-bold text-sm text-slate-950 transition-all duration-300 transform hover:scale-[1.03] active:scale-[0.99]"
                  style={{
                    background: xrayOn
                      ? 'linear-gradient(90deg, #fbbf24 0%, #f59e0b 100%)'
                      : 'linear-gradient(90deg, #7dd3fc 0%, #93c5fd 100%)',
                    boxShadow: xrayOn
                      ? '0 0 32px rgba(251, 191, 36, 0.55), inset 0 1px 1px rgba(255,255,255,0.6)'
                      : '0 0 32px rgba(125, 211, 252, 0.45), inset 0 1px 1px rgba(255,255,255,0.7)'
                  }}
                >
                  <Zap className="w-4 h-4 text-orange-600 fill-orange-500" />
                  <span>{xrayOn ? 'X-ray is ON (Inspect Organs)' : 'Turn on the X-ray'}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setAutoTourRunning((prev) => !prev)}
                  className="inline-flex items-center gap-1.5 px-4 py-3 rounded-full text-xs font-semibold bg-slate-900/90 border border-slate-700/80 text-slate-300 hover:text-white hover:border-amber-400/50 transition"
                >
                  {autoTourRunning ? (
                    <>
                      <Pause className="w-3.5 h-3.5 text-amber-400" />
                      <span>Stop Auto-Tour</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-3.5 h-3.5 text-amber-400" />
                      <span>Run Tour Video</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* CENTER COLUMN: "Ray" the Interactive Robot + Hover X-Ray Lens + Companion Props */}
            <div className="lg:col-span-5 flex flex-col items-center justify-center relative">
              <div className="relative w-full max-w-[440px] flex items-center justify-center">
                <svg
                  ref={svgRef}
                  viewBox="0 0 440 480"
                  className="w-full h-auto max-h-[500px] cursor-crosshair drop-shadow-[0_20px_50px_rgba(14,165,233,0.14)]"
                  onMouseMove={handleSvgMouseMove}
                  onMouseLeave={() => setLensPos((prev) => ({ ...prev, active: false }))}
                >
                  <defs>
                    {/* 3D Soft Gradients matching the Agent Xray Robot */}
                    <linearGradient id="rayBodyGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                      <stop offset="0%" stopColor="#f8fafc" />
                      <stop offset="55%" stopColor="#dbeafe" />
                      <stop offset="100%" stopColor="#94a3b8" />
                    </linearGradient>
                    <linearGradient id="rayLimbGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                      <stop offset="0%" stopColor="#94a3b8" />
                      <stop offset="50%" stopColor="#cbd5e1" />
                      <stop offset="100%" stopColor="#64748b" />
                    </linearGradient>
                    <radialGradient id="pedestalGlow" cx="50%" cy="50%" r="50%">
                      <stop offset="0%" stopColor="rgba(56, 189, 248, 0.38)" />
                      <stop offset="55%" stopColor="rgba(30, 58, 138, 0.25)" />
                      <stop offset="100%" stopColor="rgba(7, 11, 20, 0)" />
                    </radialGradient>
                    <radialGradient id="eyeGlow" cx="50%" cy="50%" r="50%">
                      <stop offset="0%" stopColor="#e0f2fe" />
                      <stop offset="45%" stopColor="#38bdf8" />
                      <stop offset="100%" stopColor="#0284c7" />
                    </radialGradient>

                    {/* Circular X-Ray Peek ClipPath when hovering over Ray */}
                    <clipPath id="xrayLensClip">
                      <circle
                        cx={xrayOn ? 220 : lensPos.x}
                        cy={xrayOn ? 240 : lensPos.y}
                        r={xrayOn ? 320 : lensPos.active ? 92 : 0}
                      />
                    </clipPath>
                  </defs>

                  {/* 1. Glowing Pedestal Base under Ray */}
                  <ellipse cx="220" cy="435" rx="135" ry="26" fill="url(#pedestalGlow)" />
                  <ellipse
                    cx="220"
                    cy="426"
                    rx="92"
                    ry="16"
                    fill="#111c38"
                    stroke="#334155"
                    strokeWidth="2"
                  />
                  <ellipse
                    cx="220"
                    cy="422"
                    rx="76"
                    ry="11"
                    fill="#1e293b"
                    stroke="#475569"
                    strokeWidth="1.5"
                  />

                  {/* 2. Floating Checkup Clipboard Prop (Bottom Left — Clickable!) */}
                  <g
                    className="cursor-pointer transition-transform hover:scale-110"
                    transform="translate(88, 350) rotate(-8)"
                    onClick={() => {
                      setActiveScene('checkup');
                      markDiscovered('prop-clipboard-checkup');
                    }}
                  >
                    <title>Click to open NAAC A+ &amp; NBA Audit Checkup</title>
                    <rect
                      x="0"
                      y="6"
                      width="44"
                      height="56"
                      rx="6"
                      fill="#b45309"
                      stroke="#78350f"
                      strokeWidth="2"
                    />
                    <rect x="4" y="10" width="36" height="48" rx="3" fill="#fef3c7" />
                    <rect x="13" y="2" width="18" height="8" rx="3" fill="#94a3b8" />
                    {/* Green Checkmark + Audit Lines */}
                    <path
                      d="M 10 24 L 15 29 L 23 19"
                      fill="none"
                      stroke="#10b981"
                      strokeWidth="3"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <line x1="27" y1="24" x2="35" y2="24" stroke="#94a3b8" strokeWidth="2.5" strokeLinecap="round" />
                    <line x1="10" y1="36" x2="34" y2="36" stroke="#cbd5e1" strokeWidth="2.5" strokeLinecap="round" />
                    <line x1="10" y1="45" x2="28" y2="45" stroke="#cbd5e1" strokeWidth="2.5" strokeLinecap="round" />
                  </g>

                  {/* 3. Two Mini Companion Bots (Bottom Right — Clickable!) */}
                  {/* Mint Green Mini Bot -> Student Lifecycle Tree */}
                  <g
                    className="cursor-pointer transition-transform hover:scale-110"
                    transform="translate(318, 362)"
                    onClick={() => {
                      setActiveScene('tree');
                      markDiscovered('prop-minibot-tree');
                    }}
                  >
                    <title>Click to inspect Student Academic Lifecycle Tree</title>
                    <line x1="16" y1="0" x2="16" y2="7" stroke="#94a3b8" strokeWidth="2" />
                    <circle cx="16" cy="0" r="3" fill="#f472b6" />
                    <rect x="2" y="7" width="28" height="20" rx="6" fill="#6ee7b7" />
                    <rect x="6" y="11" width="20" height="12" rx="4" fill="#0f172a" />
                    <circle cx="12" cy="17" r="2.2" fill="#38bdf8" />
                    <circle cx="20" cy="17" r="2.2" fill="#38bdf8" />
                    <rect x="7" y="29" width="18" height="15" rx="4" fill="#34d399" />
                  </g>

                  {/* Lavender Mini Bot -> Placement Drives */}
                  <g
                    className="cursor-pointer transition-transform hover:scale-110"
                    transform="translate(354, 382)"
                    onClick={() => {
                      setActiveScene('trips');
                      markDiscovered('prop-minibot-trips');
                    }}
                  >
                    <title>Click to inspect 610+ T&amp;P Placement Drives</title>
                    <line x1="12" y1="0" x2="12" y2="5" stroke="#94a3b8" strokeWidth="1.8" />
                    <circle cx="12" cy="0" r="2.4" fill="#fbbf24" />
                    <rect x="2" y="5" width="20" height="15" rx="5" fill="#d8b4fe" />
                    <rect x="5" y="8" width="14" height="9" rx="3" fill="#0f172a" />
                    <circle cx="9.5" cy="12.5" r="1.7" fill="#f472b6" />
                    <circle cx="14.5" cy="12.5" r="1.7" fill="#f472b6" />
                    <rect x="5" y="21" width="14" height="12" rx="3" fill="#c084fc" />
                  </g>

                  {/* =========================================================
                      4. EXTERIOR ROBOT BODY ("Ray")
                     ========================================================= */}
                  <g opacity={xrayOn ? 0.22 : 1} style={{ transition: 'opacity 0.35s ease' }}>
                    {/* Antenna */}
                    <line
                      x1="220"
                      y1="30"
                      x2="220"
                      y2="60"
                      stroke="#94a3b8"
                      strokeWidth="5"
                      strokeLinecap="round"
                    />
                    <circle cx="220" cy="26" r="8" fill="#f472b6" />
                    <circle cx="217" cy="23" r="2.5" fill="#fbcfe8" />

                    {/* Side Ear Pods */}
                    <rect x="122" y="102" width="16" height="44" rx="7" fill="url(#rayLimbGrad)" />
                    <rect x="302" y="102" width="16" height="44" rx="7" fill="url(#rayLimbGrad)" />

                    {/* Head Outer Shell */}
                    <rect
                      x="134"
                      y="58"
                      width="172"
                      height="126"
                      rx="38"
                      fill="url(#rayBodyGrad)"
                      stroke="#cbd5e1"
                      strokeWidth="2"
                    />

                    {/* Face Visor Screen */}
                    <rect
                      x="154"
                      y="82"
                      width="132"
                      height="82"
                      rx="24"
                      fill="#0f172a"
                      stroke="#1e293b"
                      strokeWidth="3"
                    />

                    {/* Glowing Cyan Eyes */}
                    <circle cx="188" cy="120" r="14" fill="url(#eyeGlow)" />
                    <circle cx="183" cy="115" r="4" fill="#ffffff" opacity="0.9" />
                    <circle cx="252" cy="120" r="14" fill="url(#eyeGlow)" />
                    <circle cx="247" cy="115" r="4" fill="#ffffff" opacity="0.9" />

                    {/* Cute Rosy Cheeks & Cyan Smile */}
                    <ellipse cx="168" cy="138" rx="6" ry="3.5" fill="#f43f5e" opacity="0.45" />
                    <ellipse cx="272" cy="138" rx="6" ry="3.5" fill="#f43f5e" opacity="0.45" />
                    <path
                      d="M 209 138 Q 220 148 231 138"
                      fill="none"
                      stroke="#38bdf8"
                      strokeWidth="3.5"
                      strokeLinecap="round"
                    />

                    {/* Neck */}
                    <rect x="198" y="184" width="44" height="18" rx="6" fill="url(#rayLimbGrad)" />

                    {/* Left & Right Segmented Arms */}
                    <g>
                      {/* Left Shoulder & Arm */}
                      <circle cx="142" cy="222" r="16" fill="url(#rayLimbGrad)" />
                      <path
                        d="M 134 232 L 108 308 L 128 315 L 152 240 Z"
                        fill="url(#rayLimbGrad)"
                      />
                      <circle cx="114" cy="320" r="18" fill="url(#rayBodyGrad)" />

                      {/* Right Shoulder & Arm */}
                      <circle cx="298" cy="222" r="16" fill="url(#rayLimbGrad)" />
                      <path
                        d="M 306 232 L 332 308 L 312 315 L 288 240 Z"
                        fill="url(#rayLimbGrad)"
                      />
                      <circle cx="326" cy="320" r="18" fill="url(#rayBodyGrad)" />
                    </g>

                    {/* Torso Shell */}
                    <rect
                      x="148"
                      y="198"
                      width="144"
                      height="142"
                      rx="28"
                      fill="url(#rayBodyGrad)"
                      stroke="#cbd5e1"
                      strokeWidth="2"
                    />

                    {/* Chest Control Panel (Heart + 3 Telemetry Dots, matching screenshot) */}
                    <rect
                      x="168"
                      y="220"
                      width="104"
                      height="52"
                      rx="12"
                      fill="#cbd5e1"
                      stroke="#94a3b8"
                      strokeWidth="1.5"
                    />
                    {/* Coral Heart Icon */}
                    <path
                      d="M 192 242 C 192 237 185 234 181 239 C 177 234 170 237 170 242 C 170 249 181 255 181 255 C 181 255 192 249 192 242 Z"
                      fill="#f43f5e"
                      transform="translate(8, 0)"
                    />
                    {/* 3 Colored Status Dots (Yellow, Green, Blue) + Slider Bar */}
                    <circle cx="226" cy="238" r="4.5" fill="#fbbf24" />
                    <circle cx="240" cy="238" r="4.5" fill="#10b981" />
                    <circle cx="254" cy="238" r="4.5" fill="#3b82f6" />
                    <rect x="222" y="250" width="36" height="6" rx="3" fill="#64748b" />

                    {/* Lower Belly Memory Slot */}
                    <rect
                      x="182"
                      y="284"
                      width="76"
                      height="34"
                      rx="8"
                      fill="#e2e8f0"
                      stroke="#94a3b8"
                      strokeWidth="1.5"
                    />
                    <line
                      x1="208"
                      y1="301"
                      x2="232"
                      y2="301"
                      stroke="#64748b"
                      strokeWidth="3.5"
                      strokeLinecap="round"
                    />

                    {/* Left & Right Legs + Rounded Boots */}
                    <rect x="174" y="338" width="32" height="58" rx="10" fill="url(#rayLimbGrad)" />
                    <rect x="234" y="338" width="32" height="58" rx="10" fill="url(#rayLimbGrad)" />
                    <ellipse cx="190" cy="404" rx="26" ry="16" fill="url(#rayBodyGrad)" />
                    <ellipse cx="250" cy="404" rx="26" ry="16" fill="url(#rayBodyGrad)" />
                  </g>

                  {/* =========================================================
                      5. INTERNAL X-RAY SKELETON & RCE ORGAN NODES
                         (Revealed via Hover Lens OR Full X-Ray Toggle!)
                     ========================================================= */}
                  <g clipPath="url(#xrayLensClip)">
                    {/* Dark X-Ray Cavity Silhouette */}
                    <rect
                      x="134"
                      y="58"
                      width="172"
                      height="126"
                      rx="38"
                      fill="#061024"
                      stroke="#38bdf8"
                      strokeWidth="2"
                    />
                    <rect
                      x="148"
                      y="198"
                      width="144"
                      height="142"
                      rx="28"
                      fill="#061024"
                      stroke="#38bdf8"
                      strokeWidth="2"
                    />
                    <rect
                      x="174"
                      y="338"
                      width="32"
                      height="58"
                      rx="10"
                      fill="#061024"
                      stroke="#38bdf8"
                      strokeWidth="1.5"
                    />
                    <rect
                      x="234"
                      y="338"
                      width="32"
                      height="58"
                      rx="10"
                      fill="#061024"
                      stroke="#38bdf8"
                      strokeWidth="1.5"
                    />

                    {/* Internal Neural & Spinal Circuit Buses */}
                    <path
                      d="M 220 118 L 220 298 M 220 200 L 194 248 M 220 200 L 246 252 M 220 298 L 190 382 M 220 298 L 250 382"
                      stroke="#38bdf8"
                      strokeWidth="2.2"
                      strokeDasharray="5 4"
                      opacity="0.75"
                    />

                    {/* Brain Neural lobes (6 RCE Department Nodes inside Ray's Head) */}
                    <ellipse
                      cx="220"
                      cy="118"
                      rx="58"
                      ry="36"
                      fill="rgba(56, 189, 248, 0.12)"
                      stroke="#38bdf8"
                      strokeWidth="1.5"
                      strokeDasharray="4 3"
                    />
                    {[
                      { code: 'CSE', x: 182, y: 102, c: '#38bdf8' },
                      { code: 'AIML', x: 220, y: 94, c: '#c084fc' },
                      { code: 'ECE', x: 258, y: 102, c: '#fbbf24' },
                      { code: 'EEE', x: 185, y: 134, c: '#34d399' },
                      { code: 'MECH', x: 220, y: 140, c: '#f472b6' },
                      { code: 'CIVIL', x: 255, y: 134, c: '#fb923c' }
                    ].map((b) => (
                      <g
                        key={b.code}
                        className="cursor-pointer"
                        onClick={() => {
                          setSelectedDeptId(b.code as DepartmentNode['id']);
                          setActiveScene('brain');
                          markDiscovered(`organ-dept-${b.code}`);
                        }}
                      >
                        <circle cx={b.x} cy={b.y} r="13" fill="#0f172a" stroke={b.c} strokeWidth="2" />
                        <text
                          x={b.x}
                          y={b.y + 3}
                          textAnchor="middle"
                          fill="#ffffff"
                          fontSize="7.5"
                          fontWeight="800"
                          fontFamily="monospace"
                        >
                          {b.code}
                        </text>
                      </g>
                    ))}

                    {/* Clickable Organ Hotspots (Heart/Checkup, Tree/Lifecycle, Memory, Trips/Legs) */}
                    {RAY_ANATOMY_HOTSPOTS.map((organ) => (
                      <g
                        key={organ.id}
                        className="cursor-pointer"
                        onMouseEnter={() => setHoveredOrgan(organ)}
                        onClick={() => {
                          markDiscovered(`organ-${organ.id}`);
                          if (organ.id === 'memory') {
                            setWholeMapOpen(true);
                          } else {
                            setActiveScene(organ.id as typeof activeScene);
                          }
                        }}
                      >
                        <circle
                          cx={organ.cx}
                          cy={organ.cy}
                          r="20"
                          fill={organ.color}
                          opacity="0.22"
                        />
                        <circle
                          cx={organ.cx}
                          cy={organ.cy}
                          r="11"
                          fill="#091326"
                          stroke={organ.color}
                          strokeWidth="2.5"
                        />
                        <circle cx={organ.cx} cy={organ.cy} r="4.5" fill={organ.color} />
                      </g>
                    ))}
                  </g>

                  {/* Circular X-Ray Lens Ring Rim when hovering in normal mode */}
                  {!xrayOn && lensPos.active && (
                    <g pointerEvents="none">
                      <circle
                        cx={lensPos.x}
                        cy={lensPos.y}
                        r="92"
                        fill="none"
                        stroke="#38bdf8"
                        strokeWidth="2.5"
                        strokeDasharray="8 4"
                      />
                      <circle
                        cx={lensPos.x}
                        cy={lensPos.y}
                        r="96"
                        fill="none"
                        stroke="rgba(56, 189, 248, 0.25)"
                        strokeWidth="6"
                      />
                      <text
                        x={lensPos.x}
                        y={lensPos.y - 100}
                        textAnchor="middle"
                        fill="#7dd3fc"
                        fontSize="10"
                        fontFamily="monospace"
                        fontWeight="bold"
                      >
                        RCE X-RAY SCANNER • CLICK ANY NODE
                      </text>
                    </g>
                  )}
                </svg>

                {/* Floating Organ Callout Pills when X-ray is switched ON */}
                {xrayOn && (
                  <div className="hidden sm:flex flex-col gap-2 absolute -left-6 top-12 z-20">
                    <button
                      type="button"
                      onClick={() => setActiveScene('brain')}
                      className="px-3 py-1.5 rounded-xl bg-slate-900/95 border border-sky-400/60 text-left shadow-lg hover:scale-105 transition"
                    >
                      <div className="text-[10px] font-mono text-sky-400">src/scenes/brain.tsx</div>
                      <div className="text-xs font-bold text-white">🧠 6 Engineering Depts</div>
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveScene('checkup')}
                      className="px-3 py-1.5 rounded-xl bg-slate-900/95 border border-rose-400/60 text-left shadow-lg hover:scale-105 transition"
                    >
                      <div className="text-[10px] font-mono text-rose-400">src/data/checkup.ts</div>
                      <div className="text-xs font-bold text-white">💓 NAAC A+ &amp; NBA Audit</div>
                    </button>
                  </div>
                )}

                {xrayOn && (
                  <div className="hidden sm:flex flex-col gap-2 absolute -right-6 bottom-20 z-20">
                    <button
                      type="button"
                      onClick={() => setActiveScene('tree')}
                      className="px-3 py-1.5 rounded-xl bg-slate-900/95 border border-purple-400/60 text-left shadow-lg hover:scale-105 transition"
                    >
                      <div className="text-[10px] font-mono text-purple-400">src/scenes/tree.tsx</div>
                      <div className="text-xs font-bold text-white">🌳 Student Lifecycle</div>
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveScene('trips')}
                      className="px-3 py-1.5 rounded-xl bg-slate-900/95 border border-emerald-400/60 text-left shadow-lg hover:scale-105 transition"
                    >
                      <div className="text-[10px] font-mono text-emerald-400">src/data/trips.ts</div>
                      <div className="text-xs font-bold text-white">🚀 610+ Placement Drives</div>
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* RIGHT COLUMN: Dashed Callout Card ("This is Ray...") matching screenshot */}
            <div className="lg:col-span-3 flex flex-col items-center lg:items-start justify-center z-10">
              <div
                className="w-full max-w-[265px] rounded-2xl p-5 transition-all duration-300"
                style={{
                  backgroundColor: 'rgba(15, 23, 42, 0.55)',
                  border: '1.5px dashed rgba(148, 163, 184, 0.35)',
                  boxShadow: '0 12px 32px rgba(0, 0, 0, 0.35)'
                }}
              >
                {/* Cute Cartoon Eyes Badge */}
                <div className="text-xl mb-2.5 flex items-center justify-between">
                  <span role="img" aria-label="eyes">
                    👀
                  </span>
                  <span className="text-[10px] font-mono uppercase tracking-wider px-2 py-0.5 rounded bg-sky-500/15 text-sky-300">
                    {showXrayInterior ? 'X-Ray Active' : 'Interactive'}
                  </span>
                </div>

                {hoveredOrgan && showXrayInterior ? (
                  <>
                    <div className="text-xs font-mono text-amber-300 mb-1">
                      {hoveredOrgan.organName}
                    </div>
                    <p className="text-xs sm:text-[13px] leading-relaxed text-slate-200 mb-3">
                      <strong className="text-white">{hoveredOrgan.label}:</strong>{' '}
                      {hoveredOrgan.summary}
                    </p>
                    <div className="text-[11px] font-mono text-sky-300 mb-3">
                      Maps to: {hoveredOrgan.fileMapping}
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        if (hoveredOrgan.id === 'memory') {
                          setWholeMapOpen(true);
                        } else {
                          setActiveScene(hoveredOrgan.id as typeof activeScene);
                        }
                      }}
                      className="w-full py-2 rounded-lg bg-sky-400/20 border border-sky-400/50 text-sky-200 text-xs font-bold hover:bg-sky-400 hover:text-slate-950 transition"
                    >
                      Open Scene Inspector →
                    </button>
                  </>
                ) : (
                  <>
                    <p className="text-xs sm:text-[13px] leading-relaxed text-slate-200 mb-3.5">
                      <strong className="text-white font-bold">This is Ray.</strong> Ray is our RCE
                      Eluru Academic Agent, and our example. What is inside Ray is inside every
                      autonomous department at RCE.
                    </p>
                    <p className="text-[11.5px] leading-relaxed text-slate-400">
                      Psst. Move your mouse over Ray to peek — or click any glowing organ inside Ray
                      to explore CSE, ECE, EEE, MECH, CIVIL, NAAC A+ audits &amp; placements.
                    </p>
                  </>
                )}
              </div>

              {/* Quick Scene Cards below the dashed box */}
              <div className="w-full max-w-[265px] grid grid-cols-2 gap-2 mt-3">
                <button
                  type="button"
                  onClick={() => setActiveScene('brain')}
                  className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-sky-400/60 text-left transition"
                >
                  <div className="text-[10px] font-mono text-sky-400">BRAIN.TS</div>
                  <div className="text-xs font-bold text-white mt-0.5">Departments</div>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveScene('tree')}
                  className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-purple-400/60 text-left transition"
                >
                  <div className="text-[10px] font-mono text-purple-400">TREE.TS</div>
                  <div className="text-xs font-bold text-white mt-0.5">Student Tree</div>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveScene('checkup')}
                  className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-rose-400/60 text-left transition"
                >
                  <div className="text-[10px] font-mono text-rose-400">CHECKUP.TS</div>
                  <div className="text-xs font-bold text-white mt-0.5">NAAC A+ / NBA</div>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveScene('trips')}
                  className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-emerald-400/60 text-left transition"
                >
                  <div className="text-[10px] font-mono text-emerald-400">TRIPS.TS</div>
                  <div className="text-xs font-bold text-white mt-0.5">T&amp;P Drives</div>
                </button>
              </div>
            </div>
          </div>
        </main>
      )}

      {/* ===================================================================
          SCENE 1: BRAIN.TSX — RCE DEPARTMENTS & CURRICULUM NODE GRAPH
         =================================================================== */}
      {activeScene === 'brain' && (
        <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-8 py-6 flex flex-col gap-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <button
                type="button"
                onClick={() => setActiveScene('hero')}
                className="inline-flex items-center gap-1.5 text-xs text-sky-400 hover:text-sky-300 font-semibold mb-1"
              >
                <ArrowLeft className="w-3.5 h-3.5" /> Back to Ray X-Ray Stage
              </button>
              <h2 className="text-2xl font-extrabold text-white flex items-center gap-2.5">
                <Cpu className="w-6 h-6 text-sky-400" />
                <span>RCE Neural Core — Departments &amp; Curriculum X-Ray (`src/scenes/brain.tsx`)</span>
              </h2>
            </div>
            <div className="text-xs font-mono px-3 py-1.5 rounded-lg bg-slate-900 border border-amber-400/40 text-amber-300">
              5 NBA Accredited Core Branches • 70+ Labs • Autonomous R23
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            {/* Left Interactive Radial SVG Topology (geometry.ts + Ray.tsx beams) */}
            <div className="lg:col-span-7 rounded-2xl bg-slate-900/75 border border-slate-800 p-4 flex flex-col items-center">
              <svg viewBox="0 0 640 460" className="w-full h-auto max-h-[430px]">
                <defs>
                  <radialGradient id="coreHubGrad" cx="50%" cy="50%" r="50%">
                    <stop offset="0%" stopColor="rgba(245, 183, 0, 0.35)" />
                    <stop offset="100%" stopColor="rgba(15, 23, 42, 0)" />
                  </radialGradient>
                </defs>

                {/* Concentric Orbit Rings */}
                <circle
                  cx="320"
                  cy="230"
                  r="165"
                  fill="none"
                  stroke="rgba(148, 163, 184, 0.18)"
                  strokeDasharray="6 6"
                />
                <circle
                  cx="320"
                  cy="230"
                  r="95"
                  fill="url(#coreHubGrad)"
                  stroke="rgba(56, 189, 248, 0.18)"
                />

                {/* Animated Bezier X-Ray Beams from Central Hub to Each Department */}
                {RCE_BRAIN_DATA.map((dept) => {
                  const rad = ((dept.angleDeg - 90) * Math.PI) / 180;
                  const tx = 320 + 165 * Math.cos(rad);
                  const ty = 230 + 165 * Math.sin(rad);
                  const active = dept.id === selectedDeptId;
                  return (
                    <g key={`beam-${dept.id}`}>
                      <line
                        x1="320"
                        y1="230"
                        x2={tx}
                        y2={ty}
                        stroke={active ? dept.color : '#1e293b'}
                        strokeWidth={active ? 5 : 2}
                        strokeOpacity={active ? 0.45 : 0.7}
                      />
                      <line
                        x1="320"
                        y1="230"
                        x2={tx}
                        y2={ty}
                        stroke={active ? '#ffffff' : dept.color}
                        strokeWidth={active ? 2.2 : 1.2}
                        strokeDasharray="6 5"
                      />
                    </g>
                  );
                })}

                {/* Central Autonomous Core Node */}
                <g transform="translate(320, 230)">
                  <circle r="44" fill="#0b1d3a" stroke="#f5b700" strokeWidth="3" />
                  <text y="-5" textAnchor="middle" fill="#ffffff" fontSize="12" fontWeight="800">
                    RCE ELURU
                  </text>
                  <text
                    y="11"
                    textAnchor="middle"
                    fill="#fbbf24"
                    fontSize="9"
                    fontFamily="monospace"
                  >
                    NAAC A+ CORE
                  </text>
                </g>

                {/* Orbiting Engineering Department Nodes */}
                {RCE_BRAIN_DATA.map((dept) => {
                  const rad = ((dept.angleDeg - 90) * Math.PI) / 180;
                  const tx = 320 + 165 * Math.cos(rad);
                  const ty = 230 + 165 * Math.sin(rad);
                  const active = dept.id === selectedDeptId;
                  return (
                    <g
                      key={dept.id}
                      transform={`translate(${tx}, ${ty})`}
                      className="cursor-pointer"
                      onClick={() => {
                        setSelectedDeptId(dept.id);
                        markDiscovered(`dept-node-${dept.id}`);
                      }}
                    >
                      <circle
                        r={active ? 40 : 34}
                        fill={active ? dept.color : '#0f172a'}
                        stroke={active ? '#ffffff' : dept.color}
                        strokeWidth={active ? 3 : 2}
                      />
                      <text
                        y="-3"
                        textAnchor="middle"
                        fill={active ? '#070b14' : '#ffffff'}
                        fontSize="11"
                        fontWeight="800"
                      >
                        {dept.id}
                      </text>
                      <text
                        y="11"
                        textAnchor="middle"
                        fill={active ? '#0f172a' : '#94a3b8'}
                        fontSize="8.5"
                        fontFamily="monospace"
                        fontWeight="bold"
                      >
                        {dept.intake} Seats
                      </text>
                    </g>
                  );
                })}
              </svg>

              {/* Branch Switcher Pills */}
              <div className="flex flex-wrap gap-2 justify-center mt-2">
                {RCE_BRAIN_DATA.map((d) => (
                  <button
                    key={d.id}
                    type="button"
                    onClick={() => setSelectedDeptId(d.id)}
                    className={`px-3 py-1 rounded-full text-xs font-bold transition ${
                      selectedDeptId === d.id
                        ? 'bg-amber-400 text-slate-950'
                        : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                    }`}
                  >
                    {d.shortName}
                  </button>
                ))}
              </div>
            </div>

            {/* Right Department Inspector & Curriculum Courses */}
            <div className="lg:col-span-5 rounded-2xl bg-slate-900/90 border border-slate-800 p-5 flex flex-col gap-4">
              <div>
                <span className="text-[11px] font-mono px-2.5 py-0.5 rounded bg-amber-500/15 text-amber-300 border border-amber-400/30">
                  {selectedDepartment.nbaStatus}
                </span>
                <h3 className="text-xl font-extrabold text-white mt-2">
                  {selectedDepartment.fullName}
                </h3>
                <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                  {selectedDepartment.description}
                </p>
              </div>

              <div className="grid grid-cols-3 gap-2.5">
                <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                  <div className="text-[10px] font-mono text-slate-400">FACULTY / LABS</div>
                  <div className="text-sm font-extrabold text-white mt-0.5">
                    {selectedDepartment.faculty} Fac • {selectedDepartment.labs} Labs
                  </div>
                </div>
                <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                  <div className="text-[10px] font-mono text-slate-400">PATENTS / R&amp;D</div>
                  <div className="text-sm font-extrabold text-amber-300 mt-0.5">
                    {selectedDepartment.patents} • ₹{selectedDepartment.rdFundingLakhs}L
                  </div>
                </div>
                <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                  <div className="text-[10px] font-mono text-slate-400">PLACEMENT RATE</div>
                  <div className="text-sm font-extrabold text-emerald-400 mt-0.5">
                    {selectedDepartment.placementRate}%
                  </div>
                </div>
              </div>

              <div>
                <div className="text-xs font-mono uppercase tracking-wider text-sky-400 mb-2.5">
                  Autonomous Curriculum &amp; Real Tools Mapped
                </div>
                <div className="flex flex-col gap-2.5">
                  {selectedDepartment.courses.map((course) => (
                    <div
                      key={course.code}
                      className="p-3.5 rounded-xl bg-slate-950/90 border border-slate-800/90 hover:border-sky-400/40 transition"
                    >
                      <div className="flex items-center justify-between text-xs font-mono">
                        <span className="text-amber-300 font-bold">{course.code}</span>
                        <span className="text-slate-400">
                          {course.sem} • {course.credits} Credits • {course.obe}
                        </span>
                      </div>
                      <div className="text-sm font-bold text-white mt-1">{course.title}</div>
                      <div className="flex flex-wrap gap-1.5 mt-2">
                        {course.tools.map((t) => (
                          <span
                            key={t}
                            className="text-[10px] font-mono px-2 py-0.5 rounded bg-sky-500/10 text-sky-300 border border-sky-400/20"
                          >
                            {t}
                          </span>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </main>
      )}

      {/* ===================================================================
          SCENE 2: TREE.TSX — STUDENT ACADEMIC LIFECYCLE PROGRESSION
         =================================================================== */}
      {activeScene === 'tree' && (
        <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-8 py-6 flex flex-col gap-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <button
                type="button"
                onClick={() => setActiveScene('hero')}
                className="inline-flex items-center gap-1.5 text-xs text-sky-400 hover:text-sky-300 font-semibold mb-1"
              >
                <ArrowLeft className="w-3.5 h-3.5" /> Back to Ray X-Ray Stage
              </button>
              <h2 className="text-2xl font-extrabold text-white flex items-center gap-2.5">
                <GitBranch className="w-6 h-6 text-purple-400" />
                <span>Student Academic Lifecycle Tree (`src/data/tree.ts` &amp; `src/scenes/tree.tsx`)</span>
              </h2>
            </div>
            <span className="text-xs font-mono px-3 py-1.5 rounded-lg bg-slate-900 border border-purple-400/40 text-purple-300">
              Admissions → Mid Exams → 70+ Labs Externals → 610+ Placements
            </span>
          </div>

          {/* Interactive 5-Stage Lifecycle Pipeline */}
          <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
            {RCE_TREE_DATA.map((stage) => {
              const active = stage.id === selectedStageId;
              return (
                <button
                  key={stage.id}
                  type="button"
                  onClick={() => {
                    setSelectedStageId(stage.id);
                    markDiscovered(`stage-${stage.id}`);
                  }}
                  className={`p-4 rounded-2xl border text-left transition-all flex flex-col justify-between ${
                    active
                      ? 'bg-slate-900 border-sky-400 shadow-[0_0_25px_rgba(56,189,248,0.22)]'
                      : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between text-xs font-mono mb-2">
                      <span style={{ color: stage.color }} className="font-bold">
                        STAGE {stage.stepNumber}
                      </span>
                      <span className="text-slate-400">{stage.window}</span>
                    </div>
                    <div className="text-sm font-extrabold text-white leading-snug">
                      {stage.title}
                    </div>
                  </div>
                  <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs font-mono">
                    <span className="text-slate-300">{stage.cohort} Students</span>
                    <span className="text-emerald-400 font-bold">{stage.passRate}% Clear</span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Detailed Inspector for Selected Lifecycle Stage */}
          <div className="rounded-2xl bg-slate-900/90 border border-slate-800 p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
            <div className="lg:col-span-7 flex flex-col gap-3">
              <span className="text-xs font-mono uppercase tracking-wider text-amber-300">
                {selectedLifecycle.phase} • {selectedLifecycle.window}
              </span>
              <h3 className="text-2xl font-extrabold text-white">{selectedLifecycle.title}</h3>
              <p className="text-sm text-slate-300 leading-relaxed">
                <strong className="text-white">Autonomous Evaluation &amp; Eligibility Rule:</strong>{' '}
                {selectedLifecycle.rule}
              </p>
              <div className="flex flex-col gap-2 mt-2">
                {selectedLifecycle.deliverables.map((item) => (
                  <div
                    key={item}
                    className="flex items-center gap-2.5 text-xs sm:text-sm text-slate-200 bg-slate-950/80 border border-slate-800 px-3.5 py-2.5 rounded-xl"
                  >
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="lg:col-span-5 rounded-xl bg-slate-950 border border-slate-800 p-5 flex flex-col gap-4">
              <div className="text-xs font-mono text-sky-400 uppercase">
                Stage Telemetry Readout
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800">
                  <div className="text-xs text-slate-400">Active Cohort</div>
                  <div className="text-2xl font-extrabold text-white mt-1">
                    {selectedLifecycle.cohort}
                  </div>
                </div>
                <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800">
                  <div className="text-xs text-slate-400">Progression Rate</div>
                  <div className="text-2xl font-extrabold text-emerald-400 mt-1">
                    {selectedLifecycle.passRate}%
                  </div>
                </div>
              </div>
              <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden">
                <div
                  className="bg-gradient-to-r from-sky-400 to-emerald-400 h-full rounded-full"
                  style={{ width: `${selectedLifecycle.passRate}%` }}
                />
              </div>
              <div className="text-[11px] font-mono text-slate-400">
                Monitored by RCE Autonomous Exam Cell &amp; IQAC Mentoring System.
              </div>
            </div>
          </div>
        </main>
      )}

      {/* ===================================================================
          SCENE 3: CHECKUP.TS — INSTITUTIONAL AUDIT METRICS (NAAC A+ & NBA)
         =================================================================== */}
      {activeScene === 'checkup' && (
        <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-8 py-6 flex flex-col gap-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <button
                type="button"
                onClick={() => setActiveScene('hero')}
                className="inline-flex items-center gap-1.5 text-xs text-sky-400 hover:text-sky-300 font-semibold mb-1"
              >
                <ArrowLeft className="w-3.5 h-3.5" /> Back to Ray X-Ray Stage
              </button>
              <h2 className="text-2xl font-extrabold text-white flex items-center gap-2.5">
                <ShieldCheck className="w-6 h-6 text-rose-400" />
                <span>Institutional Audit &amp; IQAC Checkup (`src/data/checkup.ts`)</span>
              </h2>
            </div>
            <span className="text-xs font-mono px-3 py-1.5 rounded-lg bg-amber-500/15 border border-amber-400/40 text-amber-300">
              NAAC A+ Grade • 5 NBA Programs • 155 Patents • ₹4.34 Cr R&amp;D
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {RCE_CHECKUP_DATA.map((item) => (
              <div
                key={item.id}
                className="rounded-2xl bg-slate-900/85 border border-slate-800 hover:border-amber-400/50 p-5 flex flex-col justify-between gap-4 transition"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <span className="text-xs font-mono text-sky-400">{item.code}</span>
                    <span className="text-[11px] font-mono font-bold px-2.5 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-400/30">
                      {item.badge}
                    </span>
                  </div>
                  <div className="text-xs font-bold uppercase tracking-wider text-amber-300">
                    {item.pillar}
                  </div>
                  <h3 className="text-lg font-extrabold text-white mt-1">{item.title}</h3>
                  <p className="text-xs text-slate-300 mt-2 leading-relaxed">{item.details}</p>
                </div>

                <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="text-[10px] font-mono text-slate-400">VERIFIED METRIC</div>
                    <div className="text-base font-extrabold text-white">{item.metricValue}</div>
                    <div className="text-[11px] text-slate-400">{item.benchmark}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-[10px] font-mono text-slate-400">AUDIT SCORE</div>
                    <div className="text-xl font-extrabold text-amber-400">{item.score}%</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </main>
      )}

      {/* ===================================================================
          SCENE 4: TRIPS.TS — TRAINING & PLACEMENT CELL DRIVES
         =================================================================== */}
      {activeScene === 'trips' && (
        <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-8 py-6 flex flex-col gap-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <button
                type="button"
                onClick={() => setActiveScene('hero')}
                className="inline-flex items-center gap-1.5 text-xs text-sky-400 hover:text-sky-300 font-semibold mb-1"
              >
                <ArrowLeft className="w-3.5 h-3.5" /> Back to Ray X-Ray Stage
              </button>
              <h2 className="text-2xl font-extrabold text-white flex items-center gap-2.5">
                <Briefcase className="w-6 h-6 text-emerald-400" />
                <span>Training &amp; Placement Cell Drives (`src/data/trips.ts`)</span>
              </h2>
            </div>

            {/* Branch Eligibility Filter */}
            <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-800 rounded-full p-1">
              {['ALL', 'CSE', 'AIML', 'ECE', 'EEE', 'MECH', 'CIVIL'].map((br) => (
                <button
                  key={br}
                  type="button"
                  onClick={() => setSelectedDriveBranch(br)}
                  className={`px-3 py-1 rounded-full text-xs font-bold transition ${
                    selectedDriveBranch === br
                      ? 'bg-emerald-400 text-slate-950'
                      : 'text-slate-300 hover:text-white'
                  }`}
                >
                  {br}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800">
              <div className="text-xs font-mono text-slate-400">2025–26 PLACEMENT OFFERS</div>
              <div className="text-2xl font-extrabold text-emerald-400 mt-1">
                610+ Offers &amp; Counting
              </div>
              <div className="text-xs text-slate-400 mt-1">600+ in 2024–25 • 520+ in 2023–24</div>
            </div>
            <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800">
              <div className="text-xs font-mono text-slate-400">RECRUITING PARTNERS</div>
              <div className="text-2xl font-extrabold text-sky-400 mt-1">50+ MNCs Visit Campus</div>
              <div className="text-xs text-slate-400 mt-1">
                Accenture, TCS, Infosys, Wipro, Enzen &amp; Formonic
              </div>
            </div>
            <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800">
              <div className="text-xs font-mono text-slate-400">ALUMNI FOOTPRINT</div>
              <div className="text-2xl font-extrabold text-amber-400 mt-1">10,000+ Placed Alumni</div>
              <div className="text-xs text-slate-400 mt-1">
                19 Years of Proven Results at RCE Eluru
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {filteredDrives.map((drive) => (
              <div
                key={drive.id}
                className="rounded-2xl bg-slate-900/85 border border-slate-800 p-5 flex flex-col justify-between gap-3"
              >
                <div>
                  <div className="flex items-center justify-between text-xs font-mono">
                    <span className="text-emerald-400 font-bold">{drive.category}</span>
                    <span className="px-2.5 py-0.5 rounded bg-amber-500/15 text-amber-300 border border-amber-400/30">
                      CTC: {drive.ctc}
                    </span>
                  </div>
                  <h3 className="text-lg font-extrabold text-white mt-1">{drive.company}</h3>
                  <div className="text-xs text-sky-300 font-semibold">{drive.role}</div>
                  <p className="text-xs text-slate-300 mt-2 italic">“{drive.highlightQuote}”</p>
                </div>

                <div className="pt-3 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2 text-xs font-mono">
                  <div className="flex flex-wrap gap-1">
                    {drive.branches.map((b) => (
                      <span
                        key={b}
                        className="px-2 py-0.5 rounded bg-slate-800 text-slate-200 border border-slate-700"
                      >
                        {b}
                      </span>
                    ))}
                  </div>
                  <div className="text-slate-300">
                    Min CGPA: <strong className="text-white">{drive.minCgpa}</strong> • Offers:{' '}
                    <strong className="text-emerald-400">{drive.offers}</strong>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </main>
      )}

      {/* ===================================================================
          SCENE 5: COPY-PASTEABLE CODE BLUEPRINT VIEW
         =================================================================== */}
      {activeScene === 'blueprint' && (
        <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-8 py-6 flex flex-col gap-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <button
                type="button"
                onClick={() => setActiveScene('hero')}
                className="inline-flex items-center gap-1.5 text-xs text-sky-400 hover:text-sky-300 font-semibold mb-1"
              >
                <ArrowLeft className="w-3.5 h-3.5" /> Back to Ray X-Ray Stage
              </button>
              <h2 className="text-2xl font-extrabold text-white flex items-center gap-2.5">
                <Code2 className="w-6 h-6 text-amber-400" />
                <span>Repository Architecture &amp; Copy-Pasteable Code (`agent-xray-main` Fork)</span>
              </h2>
            </div>
            <span className="text-xs font-mono px-3 py-1.5 rounded-lg bg-slate-900 border border-amber-400/40 text-amber-300">
              Lead Architect: Maneesha L.L.S.
            </span>
          </div>

          <div className="grid grid-cols-1 gap-5">
            {Object.entries(REPO_CODE_FILES).map(([key, item]) => (
              <div
                key={key}
                className="rounded-2xl bg-slate-900/90 border border-slate-800 overflow-hidden"
              >
                <div className="px-5 py-3 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
                  <div>
                    <span className="text-xs font-mono font-bold text-amber-300">{item.path}</span>
                    <p className="text-xs text-slate-400 mt-0.5">{item.desc}</p>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleCopyCode(key, item.code)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-white transition"
                  >
                    {copiedKey === key ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-300">Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 text-sky-400" />
                        <span>Copy Snippet</span>
                      </>
                    )}
                  </button>
                </div>
                <pre className="p-4 text-xs font-mono text-slate-200 overflow-x-auto leading-relaxed">
                  <code>{item.code}</code>
                </pre>
              </div>
            ))}
          </div>
        </main>
      )}

      {/* ===================================================================
          WHOLE MAP MODAL (`🗺️ Whole map` button in TopBar)
         =================================================================== */}
      {wholeMapOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="max-w-4xl w-full rounded-2xl bg-slate-900 border border-slate-700 p-6 shadow-2xl max-h-[88vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-5">
              <div>
                <span className="text-xs font-mono text-sky-400 uppercase">
                  135 Parts • 327 Real Tools • One Map
                </span>
                <h3 className="text-xl font-extrabold text-white mt-0.5">
                  RCE Eluru — Complete Academic X-Ray Architecture Map
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setWholeMapOpen(false)}
                className="px-3 py-1.5 rounded-lg bg-slate-800 text-xs font-bold text-slate-200 hover:bg-slate-700"
              >
                Close [ESC]
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {RAY_ANATOMY_HOTSPOTS.map((organ) => (
                <div
                  key={organ.id}
                  className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-col justify-between gap-3"
                >
                  <div>
                    <div className="flex items-center justify-between text-xs font-mono">
                      <span style={{ color: organ.color }} className="font-bold">
                        {organ.organName}
                      </span>
                      <span className="text-slate-400">
                        {organ.partCount} parts • {organ.toolCount} tools
                      </span>
                    </div>
                    <div className="text-base font-bold text-white mt-1">{organ.label}</div>
                    <p className="text-xs text-slate-300 mt-1">{organ.summary}</p>
                    <div className="text-[11px] font-mono text-slate-400 mt-2">
                      File: {organ.fileMapping}
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setWholeMapOpen(false);
                      if (organ.id !== 'memory') {
                        setActiveScene(organ.id as typeof activeScene);
                      } else {
                        setActiveScene('checkup');
                      }
                    }}
                    className="w-full py-2 rounded-lg bg-slate-900 border border-slate-700 hover:border-sky-400 text-xs font-bold text-sky-300 transition"
                  >
                    Jump to Scene →
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================
          DEVELOPER CREDITS MODAL (`⭐ Maneesha L.L.S.` button in TopBar)
         =================================================================== */}
      {creditsModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="max-w-lg w-full rounded-2xl bg-slate-900 border border-amber-400/50 p-6 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
              <div className="flex items-center gap-2">
                <Star className="w-5 h-5 text-amber-400 fill-amber-400" />
                <h3 className="text-lg font-extrabold text-white">
                  Developer &amp; Institutional Credits
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setCreditsModalOpen(false)}
                className="px-2.5 py-1 rounded bg-slate-800 text-xs font-bold text-slate-300 hover:text-white"
              >
                Close
              </button>
            </div>

            <div className="space-y-3 text-xs sm:text-sm text-slate-300">
              <div className="p-3.5 rounded-xl bg-slate-950 border border-amber-400/30">
                <div className="text-[11px] font-mono text-amber-300 uppercase">
                  Lead Full-Stack Developer &amp; System Architect
                </div>
                <div className="text-lg font-extrabold text-white mt-0.5">Maneesha L.L.S.</div>
                <div className="text-xs text-slate-400 mt-0.5">
                  Ramachandra College of Engineering (Autonomous), Vatluru, Eluru - 534007
                </div>
              </div>

              <p className="leading-relaxed">
                This application re-engineers <code className="text-sky-300">agent-xray-main</code>{' '}
                into the <strong className="text-white">RCE Eluru - Academic X-Ray Analytics Console</strong>,
                mapping departmental curricula, student lifecycles, NAAC A+ / NBA criteria, and
                placement drives onto interactive vector geometry.
              </p>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    setCreditsModalOpen(false);
                    setActiveScene('blueprint');
                  }}
                  className="flex-1 py-2.5 rounded-xl bg-amber-400 text-slate-950 font-bold text-xs hover:bg-amber-300 transition"
                >
                  View Copy-Pasteable Source Code
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setCreditsModalOpen(false);
                    setAutoTourRunning(true);
                  }}
                  className="flex-1 py-2.5 rounded-xl bg-slate-800 text-white font-bold text-xs hover:bg-slate-700 transition"
                >
                  Run Watermarked Video Tour
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ===================================================================
          BOTTOM TELEMETRY FOOTER BAR (Matches Screenshot Footer 1:1)
         =================================================================== */}
      <footer className="w-full py-3 px-4 border-t border-slate-900/90 bg-[#070b14]/90 text-center text-xs text-slate-400 flex flex-wrap items-center justify-center gap-2 z-30">
        <span className="font-mono text-slate-400">
          135 parts · 327 real tools · one map
        </span>
        <span className="text-slate-600">·</span>
        <button
          type="button"
          onClick={() => setCreditsModalOpen(true)}
          className="font-bold text-white underline decoration-amber-400/70 underline-offset-4 hover:text-amber-300 transition"
        >
          Developed by Maneesha L.L.S.
        </button>
        <span className="text-slate-600">·</span>
        <button
          type="button"
          onClick={() => setActiveScene('checkup')}
          className="inline-flex items-center gap-1 text-slate-300 hover:text-white transition"
        >
          <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
          <span>RCE Eluru (NAAC A+ &amp; NBA Accredited)</span>
        </button>
      </footer>
    </div>
  );
}
