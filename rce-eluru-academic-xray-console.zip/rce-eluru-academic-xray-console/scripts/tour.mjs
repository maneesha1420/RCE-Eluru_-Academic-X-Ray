import { chromium } from 'playwright';
import fs from 'node:fs/promises';
import path from 'node:path';

const APP_URL = process.env.RCE_XRAY_URL || 'http://localhost:5173';
const FRAMES_DIR = path.resolve('video/frames');

async function runRceAnalyticsTour() {
  await fs.mkdir(FRAMES_DIR, { recursive: true });
  const browser = await chromium.launch({ headless: true });
  const page = await browser.newPage({ viewport: { width: 1920, height: 1080 } });

  console.log(`[RCE X-Ray Tour] Opening ${APP_URL}...`);
  await page.goto(APP_URL, { waitUntil: 'networkidle' });

  await page.screenshot({ path: path.join(FRAMES_DIR, 'frame_001_hero.png') });
  const xrayBtn = page.locator('button:has-text("Turn on the X-ray")');
  if (await xrayBtn.isVisible()) {
    await xrayBtn.click();
    await page.waitForTimeout(500);
    await page.screenshot({ path: path.join(FRAMES_DIR, 'frame_002_xray_on.png') });
  }

  await browser.close();
  console.log('[RCE X-Ray Tour] Completed frame capture.');
}

runRceAnalyticsTour();
