/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        rce: {
          navy950: '#061126',
          navy900: '#0B1D3A',
          navy800: '#132B54',
          gold500: '#F5B700',
          gold400: '#FFCC33',
        },
      },
    },
  },
  plugins: [],
};
