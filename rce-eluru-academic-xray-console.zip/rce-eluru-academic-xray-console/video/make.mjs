import { execFileSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

const OUTPUT_DIR = path.resolve('video/output');
const OUTPUT_VIDEO = path.join(OUTPUT_DIR, 'rce_eluru_management_review.mp4');

fs.mkdirSync(OUTPUT_DIR, { recursive: true });

const watermark = [
  "drawbox=x=0:y=ih-52:w=iw:h=52:color=#070b14@0.9:t=fill",
  "drawtext=text='RCE Eluru - Academic X-Ray Analytics Console (NAAC A+ | NBA)':x=32:y=h-34:fontsize=20:fontcolor=#FFFFFF",
  "drawtext=text='Developed by Maneesha L.L.S.':x=w-tw-32:y=h-34:fontsize=20:fontcolor=#FFCC33"
].join(',');

execFileSync('ffmpeg', [
  '-y', '-framerate', '0.5', '-pattern_type', 'glob', '-i', 'video/frames/*.png',
  '-vf', `scale=1920:1080,${watermark}`,
  '-c:v', 'libx264', '-r', '30', '-pix_fmt', 'yuv420p',
  OUTPUT_VIDEO
], { stdio: 'inherit' });
